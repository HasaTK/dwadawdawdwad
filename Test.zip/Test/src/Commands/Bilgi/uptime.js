const { SlashCommandBuilder, EmbedBuilder } = require(`discord.js`);

module.exports = 
{
    data: new SlashCommandBuilder()
       .setName("uptime")
       .setDescription("Botun Çalışma Süresini Gösterir"),
       
    async execute(interaction) {
        const client = interaction.client; // client nesnesine interaction üzerinden erişiyoruz

        // Çalışma süresini hesaplama
        const days = Math.floor(client.uptime / 86400000);
        const hours = Math.floor((client.uptime % 86400000) / 3600000);
        const minutes = Math.floor((client.uptime % 3600000) / 60000);
        const seconds = Math.floor((client.uptime % 60000) / 1000);

        // Embed oluşturma
        const embed = new EmbedBuilder()
            .setTitle(`__${client.user.username} Çalışma Süresi__`) // client.name yerine client.user.username kullanıldı
            .setColor("Green")
            .addFields(
                { name: `Çalışma Süresi`, value: `\`${days}\` gün, \`${hours}\` saat, \`${minutes}\` dakika, \`${seconds}\` saniye.` }
            );

        // Mesajı gönderme
        await interaction.reply({ embeds: [embed] });
    },
};
