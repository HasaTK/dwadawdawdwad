const axios = require("axios");
const { EmbedBuilder, SlashCommandBuilder } = require(`discord.js`);
const config = require("../../config.js");

// API ve Grup bilgileri
const API_KEY = config.API_KEY; // Rowifi API anahtarı
const GROUP_ID = config.groupMain; // Roblox grup ID'si
const REQUIRED_ROLE_ID = 20; // Minimum role ID (yetki sınırı)

module.exports = {
    data: new SlashCommandBuilder()
        .setName("terfi")
        .setDescription("Belirtilen kişinin rütbesini bir arttırır")
        .addStringOption(option =>
            option
                .setName("roblox-user")
                .setDescription("Roblox kullanıcı adını girin")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("sebep")
                .setDescription("Sebebi giriniz")
                .setRequired(true)
        ),

    async execute(interaction) {
        const robloxUser = interaction.options.getString("roblox-user");
        const sebep = interaction.options.getString("sebep");

        // Başlangıç mesajı
        const processingEmbed = new EmbedBuilder()
            .setColor("Yellow")
            .setTitle("İşlem Devam Ediyor...")
            .setDescription("Lütfen bekleyin, terfi işlemi gerçekleştiriliyor..."); 
        await interaction.reply({ embeds: [processingEmbed], ephemeral: true });

        try {
            // Komutu kullanan kullanıcının Roblox rolünü kontrol et
            const executorResponse = await axios.get(
                `https://api.rowifi.xyz/v1/group/${GROUP_ID}/users/@me/roles`,
                {
                    headers: {
                        Authorization: `Bearer ${API_KEY}`,
                    },
                }
            );

            const executorRoleId = executorResponse.data.targetRole.rank; // Komut çalıştıranın rank değeri

            // Eğer kullanıcının rank değeri minimum yetki sınırından düşükse işlem durdurulur
            if (executorRoleId < REQUIRED_ROLE_ID) {
                const insufficientRoleEmbed = new EmbedBuilder()
                    .setColor("Red")
                    .setTitle("Yetkisiz İşlem")
                    .setDescription(
                        "Bu komutu kullanabilmek için Roblox grubunda daha yüksek bir role sahip olmanız gerekiyor."
                    );
                return interaction.editReply({ embeds: [insufficientRoleEmbed], ephemeral: true });
            }

            // Hedef kullanıcının rolünü kontrol et
            const targetRoleResponse = await axios.get(
                `https://api.rowifi.xyz/v1/group/${GROUP_ID}/users/${robloxUser}/roles`,
                {
                    headers: {
                        Authorization: `Bearer ${API_KEY}`,
                    },
                }
            );

            const targetRole = targetRoleResponse.data.targetRole;

            // Eğer komutu çalıştıran kullanıcının rolü hedef kullanıcının rolünden düşükse işlem durdurulur
            if (executorRoleId <= targetRole.rank) {
                const noPermissionEmbed = new EmbedBuilder()
                    .setColor("Red")
                    .setTitle("Yetkisiz İşlem")
                    .setDescription("Bu kişiyi terfi ettirmek için yeterli yetkiniz yok!");
                return interaction.editReply({ embeds: [noPermissionEmbed], ephemeral: true });
            }

            // Kullanıcıyı terfi ettir
            const promoteResponse = await axios.post(
                `https://api.rowifi.xyz/v1/group/${GROUP_ID}/users/${robloxUser}/promote`,
                {},
                {
                    headers: {
                        Authorization: `Bearer ${API_KEY}`,
                    },
                }
            );

            const newRole = promoteResponse.data.newRole.name; // Kullanıcının yeni rolü
            const oldRole = targetRole.name; // Kullanıcının eski rolü

            // Başarılı embed
            const successEmbed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("İşlem başarıyla tamamlandı!")
                .setDescription(
                    `**${robloxUser}** kişisi **${oldRole}** rütbesinden **${newRole}** rütbesine terfi ettirildi.`
                )
                .addFields({ name: "Sebep", value: sebep, inline: false })
                .setTimestamp();

            return interaction.editReply({ embeds: [successEmbed] });
        } catch (error) {
            // Hata durumunda kullanıcıya bilgi ver
            const errorEmbed = new EmbedBuilder()
                .setColor("Red")
                .setTitle("Hata!")
                .setDescription(
                    "Terfi işlemi sırasında bir hata oluştu. Lütfen daha sonra tekrar deneyin."
                )
                .addFields(
                    { name: "Hata Mesajı", value: error.response?.data?.message || error.message }
                )
                .setTimestamp();

            return interaction.editReply({ embeds: [errorEmbed], ephemeral: true });
        }
    },
};
