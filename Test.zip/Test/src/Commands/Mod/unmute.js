const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("unmute")
        .setDescription("Belirtilen üyenin zaman aşımını kaldırır.")
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Zaman aşımı kaldırılacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("sebep")
                .setDescription("Zaman aşımını kaldırma sebebini yazın.")
                .setRequired(true)
        ),

    async execute(interaction) {
        // Gerekli verileri al
        const { guild, options } = interaction;
        const user = options.getUser('kullanıcı'); // Hangi kullanıcıya işlem yapılacak
        const reason = options.getString('sebep') || "Sebep belirtilmedi."; // Neden kaldırıldığı
        const timeMember = guild.members.cache.get(user.id); // Kullanıcıyı sunucudan bul

        // Kullanıcı izin kontrolleri
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return await interaction.reply({ content: "Bu komutu kullanmaya yetkin yok!", ephemeral: true });
        }
        if (!timeMember) {
            return await interaction.reply({ content: "Bu kullanıcı artık bu sunucuda değil!", ephemeral: true });
        }
        if (!timeMember.communicationDisabledUntilTimestamp) {
            return await interaction.reply({ content: "Bu kullanıcı zaten susturulmamış!", ephemeral: true });
        }

        // Zaman aşımını kaldır
        try {
            await timeMember.timeout(null, reason); // null ile zaman aşımı kaldırılır
        } catch (error) {
            return await interaction.reply({ content: "Zaman aşımı kaldırılırken bir hata oluştu.", ephemeral: true });
        }

        // Başarı mesajı
        const embed = new EmbedBuilder()
            .setColor("Green")
            .setTitle("Zaman Aşımı Kaldırıldı")
            .setDescription(`${user} adlı kullanıcının zaman aşımı kaldırıldı.\n\n**Sebep:** ${reason}`)
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};
