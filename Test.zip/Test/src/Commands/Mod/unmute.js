const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("unmute")
        .setDescription("Belirtilen üyenin zaman aşımını kaldırır.")
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Zaman aşımı kaldırılacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("sebep")
                .setDescription("Zaman aşımını kaldırma sebebini yazın.")
                .setRequired(true)
        ),

    async execute(interaction) {
        const { guild, options, member } = interaction;
        const user = options.getUser('kullanıcı'); // İşlem yapılacak kullanıcı
        const reason = options.getString('sebep') || "Sebep belirtilmedi."; // Sebep
        const timeMember = guild.members.cache.get(user.id); // Sunucudaki kullanıcıyı al

        // İzin verilmiş rol ID'leri
        const allowedRoleIds = ['1233769721896374282', '1234583107676405780', '1233879749043159202','1233769764376023120']; // Rol ID'lerinizi buraya ekleyin

        // Rol kontrolü
        const hasAllowedRole = allowedRoleIds.some(roleId => member.roles.cache.has(roleId));
        if (!hasAllowedRole) {
            return await interaction.reply({ content: "Bu komutu kullanma yetkiniz yok!", ephemeral: true });
        }

        if (!timeMember) {
            return await interaction.reply({ content: "Bu kullanıcı artık bu sunucuda değil!", ephemeral: true });
        }
        if (!timeMember.communicationDisabledUntilTimestamp) {
            return await interaction.reply({ content: "Bu kullanıcı zaten susturulmamış!", ephemeral: true });
        }

        // Zaman aşımını kaldır
        try {
            await timeMember.timeout(null, reason); // null ile zaman aşımı kaldırılır
        } catch (error) {
            console.error(error);
            return await interaction.reply({ content: "Zaman aşımı kaldırılırken bir hata oluştu.", ephemeral: true });
        }

        // Başarı mesajı
        const embed = new EmbedBuilder()
            .setColor("Green")
            .setTitle("Zaman Aşımı Kaldırıldı")
            .setDescription(`${user} adlı kullanıcının zaman aşımı kaldırıldı.\n\n**Sebep:** ${reason}`)
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};
