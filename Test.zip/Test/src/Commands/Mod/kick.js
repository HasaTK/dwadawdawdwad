const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("kick")
        .setDescription("Belirtilen üyeyi atar.")
        .setDefaultMemberPermissions(PermissionsBitField.Flags.KickMembers) // PermissionsBitField ile yetki kontrolü
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Atılacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("neden")
                .setDescription("Atılma nedeni.")
                .setRequired(false)
        ),

    async execute(interaction) {
        // Kullanıcıyı ve nedeni al
        const user = interaction.options.getUser("kullanıcı");
        const reason = interaction.options.getString("neden") || "Neden belirtilmedi";
        const member = await interaction.guild.members.fetch(user.id);

        // Yetki kontrolü
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
            const noPermissionEmbed = new EmbedBuilder()
                .setColor("Red")
                .setTitle("Yetki Hatası")
                .setDescription("Bu komutu kullanmak için **Üyeleri Atma** yetkiniz yok.")
                .setTimestamp();

            return interaction.reply({ embeds: [noPermissionEmbed], ephemeral: true });
        }

        try {
            // Üyeyi at
            await member.kick({ reason });

            // Başarılı işlem mesajı
            const embed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("İşlem başarıyla tamamlandı!")
                .setDescription(`${user} başarıyla atıldı.\n\n**Sebep:** ${reason}`)
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);

            // Hata mesajı
            const errorEmbed = new EmbedBuilder()
                .setColor("Red")
                .setTitle("Bir hata oluştu!")
                .setDescription(`${user.username} kullanıcısını atamazsınız.`)
                .setTimestamp();

            await interaction.reply({
                embeds: [errorEmbed],
                ephemeral: true, // Bu kısmı değiştirmeye gerek yok, hata mesajı sadece kullanıcıya özel olacak şekilde gösterilir
            });
        }
    },
};
