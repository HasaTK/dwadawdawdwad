const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tam-yasak-kaldir')
        .setDescription('Belirtilen kullanıcının  tüm sunuculardaki banını kaldırır.')
        .addUserOption(option =>
            option.setName('kullanıcı')
                .setDescription('Banı kaldırılacak kullanıcıyı seçin')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Sebep (isteğe bağlı)')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageGuild), // Belirli izinlere sahip olanlar kullanabilir

    async execute(interaction) {
        const user = interaction.options.getUser('kullanıcı');
        const reason = interaction.options.getString('sebep') || 'Sebep belirtilmedi';

        // Yetki kontrolü: Yalnızca belirli rol ID'lerine sahip kullanıcılar komutu çalıştırabilir
        const allowedRoleIds = ['1233769721896374282', '1234583107676405780', '1233879749043159202']; // Buraya izin verilen rol ID'lerini ekleyin
        const member = interaction.member;

        const hasAllowedRole = allowedRoleIds.some(roleId => member.roles.cache.has(roleId));
        if (!hasAllowedRole) {
            return interaction.reply({ content: 'Bu komutu kullanma izniniz yok.', ephemeral: true });
        }

        // Tüm sunucularda yasak kaldırma işlemi
        try {
            const guilds = interaction.client.guilds.cache;
            const unbannedGuilds = [];

            for (const guild of guilds.values()) {
                const guildMember = await guild.bans.fetch(user.id).catch(() => null);
                if (guildMember) {
                    await guild.members.unban(user.id, reason);
                    unbannedGuilds.push(guild.name);
                }
            }

            // Embed mesajını oluşturun
            const embed = new EmbedBuilder()
                .setColor('#00ff00') // Yeşil renk
                .setTitle('İşlem Başarıyla Gerçekleşti')
                .setDescription(`${user.tag} Tüm sunuculardan banı kaldırıldı.`)
                .addFields(
                    { name: 'Sebep', value: reason, inline: true },
                    { name: 'Banı Kaldırılan Sunucular', value: unbannedGuilds.join(', ') || 'Hiçbiri yok', inline: false }
                )
                .setTimestamp()
                .setFooter({ text: `İşlem yapan: ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            await interaction.reply('Bir hata oluştu. Lütfen daha sonra tekrar deneyin.');
        }
    },
};
