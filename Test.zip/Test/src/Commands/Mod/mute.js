const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("mute")
        .setDescription("Belirtilen üyeyi susturur.")
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Susturulacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("süre")
                .setDescription("Susturma süresini belirtin (saniye, dakika, saat, gün).")
                .setRequired(true)
                .addChoices(
                    { name: "60 Seconds", value: "60" },
                    { name: "2 Minutes", value: "120" },
                    { name: "5 Minutes", value: "300" },
                    { name: "10 Minutes", value: "600" },
                    { name: "15 Minutes", value: "900" },
                    { name: "20 Minutes", value: "1200" },
                    { name: "30 Minutes", value: "1800" },
                    { name: "45 Minutes", value: "2700" },
                    { name: "1 Hour", value: "3600" },
                    { name: "2 Hour", value: "7200" },
                    { name: "3 Hour", value: "10800" },
                    { name: "5 Hour", value: "18000" },
                    { name: "10 Hour", value: "36000" },
                    { name: "1 Day", value: "86400" },
                    { name: "2 Day", value: "172800" },
                    { name: "3 Day", value: "259200" },
                    { name: "1 Week", value: "604800" },
                )
        )
        .addStringOption(option =>
            option
                .setName("sebep")
                .setDescription("Susturma sebebi.")
                .setRequired(true)
        ),

    async execute(interaction) {
        const { guild, options, member } = interaction;
        const user = options.getUser('kullanıcı');
        const duration = parseInt(options.getString('süre')); // Süreyi sayı olarak al
        const reason = options.getString('sebep') || "Neden belirtilmedi.";
        const timeMember = guild.members.cache.get(user.id);

        // İzin verilmiş rol ID'leri
        const allowedRoleIds = ['1233769721896374282', '1234583107676405780', '1233879749043159202','1233769764376023120']; // İzin verilen rol ID'lerini buraya ekleyin

        // Rol kontrolü
        const hasAllowedRole = allowedRoleIds.some(roleId => member.roles.cache.has(roleId));
        if (!hasAllowedRole) {
            return await interaction.reply({ content: "Bu komutu kullanma yetkiniz yok!", ephemeral: true });
        }

        // Kullanıcı izin kontrolleri
        if (!timeMember) {
            return await interaction.reply({ content: "Bu kullanıcı artık bu sunucuda değil!", ephemeral: true });
        }
        if (!timeMember.kickable) {
            return await interaction.reply({ content: "Bu üyeye zaman aşımı uygulayamazsınız.", ephemeral: true });
        }
        if (interaction.member.id === timeMember.id) {
            return await interaction.reply({ content: "Kendinizi susturamazsınız!", ephemeral: true });
        }
        if (timeMember.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return await interaction.reply({ content: "Adminlere zaman aşımı uygulanamaz.", ephemeral: true });
        }

        // Susturma işlemi
        try {
            await timeMember.timeout(duration * 1000, reason); // Susturma işlemi
        } catch (error) {
            console.error(error);
            return await interaction.reply({ content: "Susturma işlemi sırasında bir hata oluştu.", ephemeral: true });
        }

        // Başarı mesajı
        const embed = new EmbedBuilder()
            .setColor("Green")
            .setTitle("İşlem Başarılı")
            .setDescription(
                `${user} adlı kullanıcı ${duration / 60} dakikalığına susturuldu. \n\n**Sebep:** ${reason}`
            )
            .setTimestamp();

        const dmEmbed = new EmbedBuilder()
            .setColor("Red")
            .setDescription(
                `⚠️ **${guild.name}** sunucusunda susturuldunuz.\n\n**Sebep:** ${reason}\n` +
                `**Susturan:** ${interaction.user.tag}`
            )
            .setTimestamp();

        // Kullanıcıya DM gönderme
        await timeMember.send({ embeds: [dmEmbed] }).catch(() => null);
        await interaction.reply({ embeds: [embed] });
    }
};
