const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("mute")
        .setDescription("Belirtilen üyeyi susturur.")
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Susturulacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("süre")
                .setDescription("Susturma süresini belirtin (saniye, dakika, saat, gün).")
                .setRequired(true)
                .addChoices(
                    { name: "60 Seconds", value: "60" },
                    { name: "2 Minutes", value: "120" },
                    { name: "5 Minutes", value: "300" },
                    { name: "10 Minutes", value: "600" },
                    { name: "15 Minutes", value: "900" },
                    { name: "20 Minutes", value: "1200" },
                    { name: "30 Minutes", value: "1800" },
                    { name: "45 Minutes", value: "2700" },
                    { name: "1 Hour", value: "3600" },
                    { name: "2 Hour", value: "7200" },
                    { name: "3 Hour", value: "10800" },
                    { name: "5 Hour", value: "18000" },
                    { name: "10 Hour", value: "36000" },
                    { name: "1 Day", value: "86400" },
                    { name: "2 Day", value: "172800" },
                    { name: "3 Day", value: "259200" },
                    { name: "1 Week", value: "604800" },
                )
        )
        .addStringOption(option =>
            option
                .setName("sebep")
                .setDescription("Susturma Sebepi.")
                .setRequired(true)
        ),

    async execute(interaction) {
        const { guild, options } = interaction;
        const user = options.getUser('kullanıcı');
        const duration = parseInt(options.getString('süre')); // Süreyi direkt sayıya çeviriyoruz
        const reason = options.getString('sebep') || "Neden belirtilmedi.";
        const timeMember = guild.members.cache.get(user.id);

        // Kullanıcı izin kontrolleri
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return await interaction.reply({ content: "Bu komutu kullanmaya yetkin yok!", flags: 64 });
        }
        if (!timeMember) {
            return await interaction.reply({ content: "Bu kullanıcı artık bu sunucuda değil!", flags: 64 });
        }
        if (!timeMember.kickable) {
            return await interaction.reply({ content: "Bu üyeye zaman aşımı uygulayamazsınız.", flags: 64 });
        }
        if (interaction.member.id === timeMember.id) {
            return await interaction.reply({ content: "Kendinizi susturamazsınız!", flags: 64 });
        }
        if (timeMember.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return await interaction.reply({ content: "Adminlere zaman aşımı uygulanamaz.", flags: 64 });
        }

        // Susturma işlemi
        await timeMember.timeout(duration * 1000, reason); // duration saniye cinsinden geldiği için 1000 ile çarpıyoruz

        const embed = new EmbedBuilder()
            .setColor("Green")
            .setTitle("İşlem Başarılı")
            .setDescription(
                `${user} adlı kullanıcı ${duration / 60} dakikalığına susturuldu. \n\n**Sebep:** ${reason}`
            )
            .setTimestamp();

        const dmEmbed = new EmbedBuilder()
            .setColor("Red")
            .setDescription(`⚠️ ${guild.name} sunucusunda susturuldunuz.\n\n **Sebep**: ${reason}`);

        // Kullanıcıya DM gönderme
        await timeMember.send({ embeds: [dmEmbed] }).catch(() => null);
        await interaction.reply({ embeds: [embed] });
    }
};
