const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tam-yasakla')
        .setDescription('Belirtilen kullanıcıyı botun bulunduğu tüm sunuculardan yasaklar.')
        .addUserOption(option =>
            option.setName('kullanıcı')
                .setDescription('Yasaklanacak kullanıcıyı seçin')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Yasaklama nedeni (isteğe bağlı)')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild), // Belirli izinlere sahip olanlar kullanabilir

    async execute(interaction) {
        const user = interaction.options.getUser('kullanıcı');
        const reason = interaction.options.getString('sebep') || 'Belirtilmedi';

        // Kontrol: Yalnızca belirli rol ID'lerine sahip kullanıcılar komutu çalıştırabilir
        const allowedRoleIds = ['1233769721896374282', '1234583107676405780', '1233879749043159202']; // Buraya izin verilen rol ID'lerini ekleyin
        const member = interaction.member;

        const hasAllowedRole = allowedRoleIds.some(roleId => member.roles.cache.has(roleId));
        if (!hasAllowedRole) {
            return interaction.reply({ content: 'Bu komutu kullanma izniniz yok.', ephemeral: true });
        }

        // Tüm sunucularda yasaklama işlemi
        try {
            const guilds = interaction.client.guilds.cache;
            const bannedGuilds = [];

            // DM Embed mesajını oluştur
            const dmEmbed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('⚠️ Yasaklandınız')
                .setDescription(
                    `Botun bulunduğu tüm sunuculardan yasaklandınız.\n\n**Sebep:** ${reason}\n` +
                    `**Yasaklayan:** ${interaction.user.tag}`
                )
                .setTimestamp();

            // Kullanıcıya DM gönder
            await user.send({ embeds: [dmEmbed] }).catch(() => {
                console.log(`${user.tag} adlı kullanıcıya DM gönderilemedi.`);
            });

            for (const guild of guilds.values()) {
                const guildMember = await guild.members.fetch(user.id).catch(() => null);
                if (guildMember) {
                    await guildMember.ban({ reason: reason });
                    bannedGuilds.push(guild.name);
                }
            }

            // Embed mesajını oluşturun
            const embed = new EmbedBuilder()
                .setColor('#00ff00') // Yeşil renk
                .setTitle('İşlem Başarıyla Gerçekleşti')
                .setDescription(`${user} adlı kullanıcı tüm sunuculardan yasaklandı.`)
                .addFields(
                    { name: 'Sebep', value: reason, inline: true },
                    { name: 'Yasaklanan Sunucular', value: bannedGuilds.join(', ') || 'Hiçbiri yok', inline: false }
                )
                .setTimestamp()
                .setFooter({ text: `İşlem yapan: ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'Bir hata oluştu. Lütfen daha sonra tekrar deneyin.', ephemeral: true });
        }
    },
};
