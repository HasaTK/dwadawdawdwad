const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("ban")
        .setDescription("Belirtilen üyeyi banlar.")
        .setDefaultMemberPermissions(PermissionsBitField.Flags.BanMembers) // PermissionsBitField kullanımı
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Banlanacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("sebep")
                .setDescription("Banlanma Sebebi.")
                .setRequired(false)
        ),

    async execute(interaction) {
        const user = interaction.options.getUser("kullanıcı");
        const reason = interaction.options.getString("sebep") || "Sebep belirtilmedi";

        // Yetki kontrolü
        if (!interaction.memberPermissions.has(PermissionsBitField.Flags.BanMembers)) {
            const noPermissionEmbed = new EmbedBuilder()
                .setColor("Red")
                .setTitle("Yetki Hatası")
                .setDescription("Bu komutu kullanmak için **Üyeleri Banlama** yetkiniz yok.")
                .setTimestamp();

            return interaction.reply({ embeds: [noPermissionEmbed], ephemeral: true });
        }

        try {
            const member = await interaction.guild.members.fetch(user.id);

            // Üyeyi banla
            await member.ban({ reason });

            // Başarılı işlem mesajı
            const embed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("İşlem başarıyla tamamlandı!")
                .setDescription(`${user} başarıyla banlandı.\n\n**Sebep:** ${reason}`)
                .setTimestamp();

            const dmEmbed = new EmbedBuilder()
                .setColor("Red")
                .setDescription(`⚠️ ${interaction.guild.name} Sunucusundan Banlandınız.\n\n **Sebep**: ${reason}`);

            // Kullanıcıya DM gönderme
            await member.send({ embeds: [dmEmbed] }).catch(() => null);

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);

            // Eğer etkileşim zaten yanıtlanmışsa kontrol edin
            if (interaction.replied || interaction.deferred) {
                return;
            }

            // Hata mesajı
            const errorEmbed = new EmbedBuilder()
                .setColor("Red")
                .setTitle("Bir hata oluştu!")
                .setDescription(`${user.username} kullanıcısını banlayamıyorum.`)
                .setTimestamp();

            await interaction.reply({
                embeds: [errorEmbed],
                ephemeral: true,
            });
        }
    },
};
