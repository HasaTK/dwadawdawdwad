const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("ban")
        .setDescription("Belirtilen üyeyi banlar.")
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Banlanacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("sebep")
                .setDescription("Banlanma Sebepi.")
                .setRequired(false)
        ),

    async execute(interaction) {
        const user = interaction.options.getUser("kullanıcı");
        const reason = interaction.options.getString("sebep") || "sebep belirtilmedi";

        try {
            const member = await interaction.guild.members.fetch(user.id);

            // Üyeyi banla
            await member.ban({ reason });

            // Başarılı işlem mesajı
            const embed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("İşlem başarıyla tamamlandı!")
                .setDescription(`${user} başarıyla banlandı.\n\n**Sebep:** ${reason}`)
                .setTimestamp();
            
                const dmEmbed = new EmbedBuilder()
                .setColor("Red")
                .setDescription(`⚠️ ${guild.name} Sunucusundan Banlandınız.\n\n **Sebep**: ${reason}`);
                
            // Kullanıcıya DM gönderme
            await timeMember.send({ embeds: [dmEmbed] }).catch(() => null);

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);

            // Eğer etkileşim zaten yanıtlanmışsa kontrol edin
            if (interaction.replied || interaction.deferred) {
                return;
            }

            // Hata mesajı
            const errorEmbed = new EmbedBuilder()
                .setColor("Red")
                .setTitle("Bir hata oluştu!")
                .setDescription(`${user.username} kullanıcısını banlayamıyorum.`)
                .setTimestamp();


            await interaction.reply({
                embeds: [errorEmbed],
                ephemeral: true,
            });
        }
    },
};
