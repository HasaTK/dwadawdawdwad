const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("unban")
        .setDescription("Belirtilen üyenin banını kaldır.")
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
        .addStringOption(option =>
            option
                .setName("userid")
                .setDescription("Banını kaldırmak istediğiniz üyenin ID'sini girin.")
                .setRequired(true)
        ),

    async execute(interaction) {
        const userId = interaction.options.getString("userid");

        try {
            const guild = interaction.guild;

            // Üyeyi unban yap
            await guild.members.unban(userId);

            // Başarılı işlem mesajı
            const embed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("İşlem başarıyla tamamlandı!")
                .setDescription(`<@${userId}> kullanıcısının banı kaldırıldı.`) // Kullanıcıyı etiketler
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);

            // Eğer etkileşim zaten yanıtlanmışsa kontrol edin
            if (interaction.replied || interaction.deferred) {
                return;
            }

            // Hata mesajı
            const errorEmbed = new EmbedBuilder()
                .setColor("Red")
                .setTitle("Bir hata oluştu!")
                .setDescription(
                    `Geçerli bir kullanıcı ID'si giriniz veya bu kullanıcı banlı olmayabilir.`
                )
                .setTimestamp();

            await interaction.reply({
                embeds: [errorEmbed],
                ephemeral: true, // Kullanıcıya özel mesaj gönderilir
            });
        }
    },
};
