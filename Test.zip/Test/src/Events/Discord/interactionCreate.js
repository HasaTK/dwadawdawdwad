const { EmbedBuilder } = require('discord.js');
const consola = require('consola');

module.exports = {
    name: "interactionCreate",
    run: async (client, interaction) => {
        if (!interaction.isChatInputCommand()) return;

        const command = client.commands.get(interaction.commandName);
        if (!command) {
            consola.warn(`Komut bulunamadı: ${interaction.commandName}`);
            return;
        }

        try {
            // "run" yerine "execute" fonksiyonu çağrılıyor
            await command.execute(interaction);
        } catch (error) {
            consola.error(`Komut çalıştırılırken hata oluştu: ${interaction.commandName}`);
            consola.error(error);

            await interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor("Red")
                        .setTitle("Bir hata oluştu!")
                        .setDescription("Bu komut çalıştırılırken bir hata meydana geldi."),
                ],
                ephemeral: true,
            });
        }
    },
};
