const consola = require('consola');
const Chalk = require('chalk');
const { Collection, Colors, PermissionFlagsBits, Role, version } = require('discord.js');
const Moment = require('moment');
const os = require('os');
const process = require('process');
Moment.locale('tr');

module.exports = {
    name: "ready",
    run: async (client) => {
        // Başlangıç mesajlarını hemen göster
        console.log(Chalk.bgBlack.bold(Chalk.white('—————————— [Bot Başlangıç] ——————————')));
        console.log(Chalk.white(`🎉 ${Chalk.green.bold('Başarıyla Bağlanıldı!')}`) + ` ${Chalk.gray(`| ${Moment().format('LLLL')}`)}`);
        console.log(Chalk.white(`🔰 Bot Kullanıcı Adı: `) + Chalk.cyan(`${client.user.tag}`));
        console.log(Chalk.white(`🌐 Ping: `) + Chalk.magenta(`${client.ws.ping}ms`));

        console.log(Chalk.bgBlack.bold(Chalk.white('—————————— [Bot Bilgisi] ——————————')));
        console.log(Chalk.white(`🌍 Toplam Sunucu Sayısı: `) + Chalk.yellow(`${client.guilds.cache.size}`));
        console.log(Chalk.white(`👥 Toplam Kullanıcı Sayısı: `) + Chalk.yellow(`${client.users.cache.size}`));
        console.log(Chalk.white(`⚡ Yüklü Komut Sayısı: `) + Chalk.yellow(`${client.commands.size}`));

        // Activity status
        const activityStatus = client.user.presence?.activities[0] || 'No activity set';
        console.log(Chalk.white(`🎮 Aktivite Durumu: `) + Chalk.green(`${activityStatus.name} ${activityStatus.details || ''}`));

        // 5 saniye sonra sistem istatistiklerini yazdırmak için setTimeout kullanıyoruz
        setTimeout(() => {
            console.log(Chalk.bgBlack.bold(Chalk.white('—————————— [Sistem İstatistikleri] ——————————')));
            console.log(
                Chalk.gray(`🔧 Discord.js Versiyonu: ${version}`) + ` | ${Chalk.green(`Node.js Versiyonu: ${process.version}`)}\n` +
                Chalk.green(`💻 Platform: ${process.platform} ${process.arch}`)
            );

            // Sistem Kaynakları: RAM ve CPU kullanımı
            const totalMem = os.totalmem() / 1024 / 1024 / 1024; // GB cinsinden
            const freeMem = os.freemem() / 1024 / 1024 / 1024; // GB cinsinden
            const cpuUsage = process.cpuUsage().user / 1000 / 1000; // ms cinsinden
            console.log(
                Chalk.white(`🧠 RAM Kullanımı: `) + Chalk.yellow(`${(totalMem - freeMem).toFixed(2)} GB / ${totalMem.toFixed(2)} GB`));
            console.log(Chalk.white(`💡 CPU Kullanımı: `) + Chalk.yellow(`${cpuUsage.toFixed(2)} ms`));

            // Bot'un uptime (çalışma süresi)
            const uptime = Moment.duration(client.uptime).humanize();
            console.log(Chalk.white(`⏳ Bot Çalışma Süresi: `) + Chalk.green(`${uptime}`));
            
            console.log(Chalk.bgBlack.bold(Chalk.white('—————————————————————————————————————')));
            consola.success(Chalk.bold.green(`${client.user.tag} başarıyla başlatıldı! 🎉`));
        }, 5000); // 5 saniye sonra sistem bilgilerini yazdır
    }
};
