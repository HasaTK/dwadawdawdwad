const { EmbedBuilder } = require('discord.js');
const consola = require('consola');

module.exports = {
    name: "interactionCreate",
    run: async (client, interaction) => {
        // Autocomplete işlemi
        if (interaction.isAutocomplete()) {
            const command = client.commands.get(interaction.commandName);
            if (!command || !command.autocomplete) return;

            try {
                await command.autocomplete(interaction);
            } catch (error) {
                consola.error('Autocomplete sırasında hata oluştu:', error);

                // Hata durumunda bir cevap gönder
                if (!interaction.responded) {
                    try {
                        await interaction.respond([{ name: 'Hata oluştu', value: '0' }]);
                    } catch (responseError) {
                        consola.error('Autocomplete hata cevabı gönderilirken hata oluştu:', responseError);
                    }
                }
            }
            return; // Diğer işlemlere devam etmesini engellemek için burada durduruyoruz.
        }

        // Sadece Chat Input Komutlarını İşle
        if (!interaction.isChatInputCommand()) return;

        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        // Sunucu dışı komutları engelle
        if (!interaction.guild) {
            try {
                await interaction.reply({
                    content: 'Bu komut sadece sunucularda kullanılabilir.',
                    ephemeral: true,
                });
            } catch (error) {
                consola.error('Sunucu dışı komut engelleme cevabında hata oluştu:', error);
            }
            return;
        }

        // Komut çalıştırma
        try {
            await command.execute(interaction);
        } catch (error) {
            consola.error('Komut çalıştırılırken hata oluştu:', error);

            // Hata mesajı gönderme
            if (!interaction.replied && !interaction.deferred) {
                try {
                    await interaction.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setTitle('⚠️ Bir hata oluştu!')
                                .setDescription('Komut çalıştırılırken bir hata oluştu. Lütfen daha sonra tekrar deneyin.')
                                .setColor('33ef5a'),
                        ],
                        ephemeral: true,
                    });
                } catch (replyError) {
                    consola.error('Hata mesajı gönderilirken bir sorun oluştu:', replyError);
                }
            } else {
                try {
                    await interaction.followUp({
                        content: '⚠️ Bir hata oluştu. Lütfen logları kontrol edin.',
                        ephemeral: true,
                    });
                } catch (followUpError) {
                    consola.error('Hata follow-up cevabı gönderilirken bir sorun oluştu:', followUpError);
                }
            }
        }
    },
};