const mongoose = require("mongoose");

const BannedUserSchema = new mongoose.Schema({
    robloxUsername: { type: String, required: true },
    reason: { type: String, required: true },
    expirationDate: { type: Date, required: true },
});

module.exports = mongoose.model("BannedUser", BannedUserSchema);
