class CooldownManager {
    constructor() {
        this.cooldowns = new Map();
    }

    startCooldown(userId, action, durationInSeconds) {
        const key = `${userId}-${action}`;
        const now = Date.now();
        const cooldownEnd = now + durationInSeconds * 1000;

        this.cooldowns.set(key, cooldownEnd);
    }

    isOnCooldown(userId, action) {
        const key = `${userId}-${action}`;
        const now = Date.now();

        if (this.cooldowns.has(key) && this.cooldowns.get(key) > now) {
            return true;
        }
        return false;
    }

    getRemainingTime(userId, action) {
        const key = `${userId}-${action}`;
        const now = Date.now();

        if (this.cooldowns.has(key)) {
            return Math.max(0, (this.cooldowns.get(key) - now) / 1000);
        }
        return 0;
    }
}

module.exports = CooldownManager;
