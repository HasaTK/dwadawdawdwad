const fs = require('fs');
const path = require('path');
const consola = require('consola');

module.exports = (client) => {
    try {
        // Events dizininin yolu
        const eventsPath = path.join(__dirname, '../Events');

        // Tüm kategorileri oku
        const categories = fs.readdirSync(eventsPath);

        for (const category of categories) {
            const categoryPath = path.join(eventsPath, category);
            const eventFiles = fs.readdirSync(categoryPath).filter(file => file.endsWith('.js'));

            for (const file of eventFiles) {
                const filePath = path.join(categoryPath, file);
                const event = require(filePath);

                // Event'in doğru bir yapılandırmaya sahip olup olmadığını kontrol et
                if (!event.name || typeof event.run !== 'function') {
                    consola.warn(`[WARNING] ${filePath} geçerli bir event dosyası değil.`);
                    continue;
                }

                // Event'i client'e bağla
                client.on(event.name, event.run.bind(null, client));
                consola.success(`✔ Event yüklendi: ${event.name}`);
            }
        }
    } catch (error) {
        consola.error('Event yüklerken bir hata oluştu:', error);
    }
};
