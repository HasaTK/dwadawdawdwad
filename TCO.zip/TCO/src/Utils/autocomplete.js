const noblox = require('noblox.js');
const config = require('../config'); // Config dosyasından groupId alınır

module.exports = async function autocomplete(interaction) {
    const focusedOption = interaction.options.getFocused();
    const groupId = config.groupMain; // Sabit groupId buradan alınır.

    try {
        // Roblox grup rollerini al
        const roles = await noblox.getRoles(groupId);
        
        // Autocomplete aramasına uygun rolleri filtrele
        const filteredRoles = roles
            .filter(role => role.name.toLowerCase().includes(focusedOption.toLowerCase()))
            .slice(0, 25); // Discord, en fazla 25 seçenek gösterir

        // Filtrelenmiş rollerin autocomplete seçeneklerini döndür
        await interaction.respond(
            filteredRoles.map(role => ({ name: role.name, value: role.name }))
        );
    } catch (error) {
        console.error('Autocomplete sırasında bir hata oluştu:', error);
        
        // Hata durumunda kullanıcıya bilgi ver
        await interaction.respond([{ name: 'Hata oluştu', value: 'Roller alınamadı.' }]);
    }
};