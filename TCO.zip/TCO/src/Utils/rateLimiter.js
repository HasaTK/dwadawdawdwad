const limits = {};  // Burada her kullanıcı için ayrı limitler tutacağız

const MAX_USAGE_PER_HOUR = 25;  // Saatlik maksimum 25 kullanım
const COOLDOWN_MS = 3500;  // 3.5 saniye bekleme süresi

function canUseCommand(userId) {
    const now = Date.now();

    // Kullanıcı için limit bilgilerini al
    if (!limits[userId]) {
        limits[userId] = {
            usageTimes: [],
            lastUsageTime: 0,
        };
    }

    const userLimits = limits[userId];

    // 3.5 saniye bekleme süresi kontrolü
    if (now - userLimits.lastUsageTime < COOLDOWN_MS) {
        return { allowed: false, message: "Lütfen 3.5 saniye bekleyin!" };
    }

    // Eski kullanımları temizle (saatlik sınır için)
    userLimits.usageTimes = userLimits.usageTimes.filter(time => now - time < 3600000);

    // Saatlik sınırı kontrol et
    if (userLimits.usageTimes.length >= MAX_USAGE_PER_HOUR) {
        return { allowed: false, message: "Saatlik komut limitine ulaşıldı!" };
    }

    // Kullanım izni ver
    userLimits.usageTimes.push(now);
    userLimits.lastUsageTime = now;
    return { allowed: true };
}

module.exports = { canUseCommand };
