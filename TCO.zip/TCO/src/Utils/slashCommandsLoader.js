const { ApplicationCommandType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const consola = require('consola');

const CommandArray = [];

module.exports = (client) => {
    try {
        // Komut dosyalarının bulunduğu ana dizin
        const commandsPath = path.join(__dirname, '../Commands');
        const categories = fs.readdirSync(commandsPath); // Kategorileri oku

        for (const category of categories) {
            const categoryPath = path.join(commandsPath, category);
            const commandFiles = fs.readdirSync(categoryPath).filter(file => file.endsWith('.js')); // Sadece .js dosyalarını al

            for (const file of commandFiles) {
                const filePath = path.join(categoryPath, file);

                try {
                    const commandFile = require(filePath);

                    if (!commandFile.data || !commandFile.data.name) {
                        consola.warn(`⚠️ Eksik veya hatalı komut dosyası: ${file}`);
                        continue;
                    }

                    // Mesaj veya kullanıcı tipi komutlar için
                    if ([ApplicationCommandType.Message, ApplicationCommandType.User].includes(commandFile.data.type)) {
                        client.context.set(commandFile.data.name, commandFile);
                    } else {
                        // Slash komutları için
                        client.commands.set(commandFile.data.name, commandFile);
                        CommandArray.push(commandFile.data.toJSON());
                    }
                } catch (error) {
                    consola.error(`❌ Komut yüklenirken hata oluştu: ${file}`, error);
                }
            }
        }

        // Bot hazır olduğunda komutları yükle
        client.on('ready', async () => {
            try {
                const config = client.config;

                if (config.bot.komutları_sil) {
                    // Tüm komutları temizle
                    await client.application.commands.set([]);
                    if (config.developerServer) {
                        await client.guilds.cache.get(config.developerServer)?.commands.set([]);
                    }
                    consola.success('✔️ Tüm komutlar temizlendi.');
                } else if (config.bot.global_komutlar) {
                    // Global komutları yükle
                    await client.application.commands.set(CommandArray);
                    consola.success('✔️ Global komutlar yüklendi.');
                } else if (config.developerServer) {
                    // Sadece belirli bir sunucuya komutları yükle
                    await client.guilds.cache.get(config.developerServer)?.commands.set(CommandArray);
                    consola.success(`✔️ Komutlar "${config.developerServer}" sunucusuna yüklendi.`);
                }
            } catch (error) {
                consola.error('❌ Komutlar yüklenirken hata oluştu:', error);
            }
        });
    } catch (error) {
        consola.error('❌ Komut yüklenici sırasında bir hata oluştu:', error);
    }
};
