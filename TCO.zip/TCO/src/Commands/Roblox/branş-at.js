const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const noblox = require('noblox.js');
const rowifiRequest = require('../../Utils/rowifiRequest');
const config = require('../../config');

const branches = {
    "Askeri Inzibat Kuvvetleri": { groupId: config.groupAsiz, logChannelId: "1233770055121113098", requiredRankId: 19 },
    "Hava Kuvvetleri Komutanlığı": { groupId: config.groupHkk, logChannelId: "1233770051811803217", requiredRankId: 20 },
    "Özel Kuvvetler Komutanlığı": { groupId: config.groupOkk, logChannelId: "1234530438542921748", requiredRankId: 19 },
    "Jandarma Genel Komutanlığı": { groupId: config.groupJan, logChannelId: "1234530208711839754", requiredRankId: 19 },
    "Kara Kuvvetleri Komutanlığı": { groupId: config.groupKkk, logChannelId: "1233770048619937882", requiredRankId: 29 },
    "Sınır Müfettişleri": { groupId: config.groupSm, logChannelId: "1234530377146568814", requiredRankId: 18 },
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('brans-at')
        .setDescription('Belirtilen kullanıcıyı seçilen branştan atar.')
        .addStringOption(option =>
            option.setName('kullanıcı')
                .setDescription('Atılacak kullanıcının Roblox kullanıcı adı')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('brans')
                .setDescription('İşlem uygulanacak branş')
                .setRequired(true)
                .addChoices(
                    ...Object.keys(branches).map(branch => ({ name: branch, value: branch }))
                )
        )
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Atma işleminin sebebi')
                .setRequired(true)
        ),

    async execute(interaction) {
        const robloxUsername = interaction.options.getString('kullanıcı');
        const branchName = interaction.options.getString('brans');
        const reason = interaction.options.getString('sebep');
        const discordUserId = interaction.user.id;

        const branchData = branches[branchName];
        const branchGroupId = branchData.groupId;
        const logChannelId = branchData.logChannelId;

        if (reason.length < 3) {
            return interaction.reply({
                content: '⚠️ Sebep en az 3 karakter uzunluğunda olmalıdır.',
                ephemeral: true,
            });
        }

        await interaction.deferReply();

        try {
            const rowifiData = await rowifiRequest(`/guilds/${interaction.guild.id}/members/${discordUserId}`);
            if (!rowifiData || !rowifiData.roblox_id) {
                return interaction.editReply({
                    content: `🚨 Bu komutu kullanabilmek için önce Discord hesabınızı Rowifi üzerinden Roblox hesabınıza bağlamanız gerekiyor.`,
                    ephemeral: true,
                });
            }

            const robloxUserId = rowifiData.roblox_id;

            // Kullanıcının mevcut rütbesini kontrol et
            const userCurrentRankId = await noblox.getRankInGroup(branchGroupId, robloxUserId);
            const userCurrentRankName = await noblox.getRankNameInGroup(branchGroupId, robloxUserId);

            if (userCurrentRankId === 0) {
                return interaction.editReply({
                    content: '⚠️ Roblox hesabınız belirtilen gruba üye değil.',
                    ephemeral: true,
                });
            }

            const exileRobloxUserId = await noblox.getIdFromUsername(robloxUsername).catch(() => null);
            if (!exileRobloxUserId) {
                return interaction.editReply({
                    content: `⚠️ Kullanıcı adı "${robloxUsername}" geçerli değil veya kullanıcı bulunamadı.`,
                    ephemeral: true,
                });
            }

            const exileCurrentRankId = await noblox.getRankInGroup(branchGroupId, exileRobloxUserId);
            const exileCurrentRankName = await noblox.getRankNameInGroup(branchGroupId, exileRobloxUserId);

            if (exileCurrentRankId === 0) {
                return interaction.editReply({
                    content: `⚠️ Bu kullanıcı (${robloxUsername}) belirtilen branş grubuna üye değil.`,
                    ephemeral: true,
                });
            }

            if (exileCurrentRankId >= userCurrentRankId) {
                return interaction.editReply({
                    content: `⚠️ Hedef kullanıcının rütbesi (${exileCurrentRankName}) sizin rütbenize (${userCurrentRankName}) eşit veya daha yüksek.`,
                    ephemeral: true,
                });
            }

            await noblox.exile(branchGroupId, exileRobloxUserId);

            const botAvatarURL = interaction.client.user.displayAvatarURL({ dynamic: true, size: 512 });

            // Embed tasarımı
            const embed = new EmbedBuilder()
                .setColor('#ff4c4c')
                .setAuthor({ name: '✅ Kullanıcı Branştan Atıldı!' })
                .setThumbnail(botAvatarURL) // Botun profil resmi
                .setDescription(`Kullanıcı başarılı bir şekilde **${branchName}** branşından atıldı.`)
                .addFields(
                    { name: '👤 Kullanıcı', value: `\`${robloxUsername}\``, inline: true },
                    { name: '📌 Önceki Rütbe', value: `\`${exileCurrentRankName}\``, inline: true },
                    { name: '📋 Sebep', value: reason, inline: false }
                )
                .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor('#ff4c4c')
                    .setAuthor({ name: '📜 Branş Atma Log' })
                    .setDescription(`Branş atma işlemi başarıyla tamamlandı.`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `\`${robloxUsername}\``, inline: true },
                        { name: '📌 Önceki Rütbe', value: `\`${exileCurrentRankName}\``, inline: true },
                        { name: '🛠️ İşlem Yapan', value: rowifiData.roblox_username || interaction.member.displayName, inline: true },
                        { name: '📋 Sebep', value: reason, inline: false }
                    )
                    .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            } else {
                console.error(`Belirtilen log kanalı bulunamadı: ${logChannelId}`);
            }
        } catch (error) {
            console.error('Branş atma işlemi sırasında bir hata oluştu:', error);

            await interaction.editReply({
                content: '⚠️ Bir hata oluştu. Lütfen daha sonra tekrar deneyin.',
                ephemeral: true,
            });
        }
    },
};
