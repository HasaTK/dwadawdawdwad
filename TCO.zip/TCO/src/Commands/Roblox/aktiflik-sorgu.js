const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUniverseDetails } = require('../../Utils/roblox');

const PLACE_ID = 86644961278890; // Türk Asker Oyunu Place ID
const UNIVERSE_ID = 6890287637; // Türk Asker Oyunu Universe ID

module.exports = {
    data: new SlashCommandBuilder()
        .setName('aktiflik-sorgu')
        .setDescription('Bir Roblox oyununun bilgilerini sorgular.'),
    async execute(interaction) {
        try {
            const universeInfo = await getUniverseDetails(UNIVERSE_ID);

            if (!universeInfo) {
                return interaction.reply({
                    content: 'Geçersiz bir Universe ID girdiniz veya oyun bulunamadı.',
                    ephemeral: true,
                });
            }

            const activePlayers = universeInfo.playing || 0;

            const embed = new EmbedBuilder()
                .setColor(0x00FF00) // Yeşil renk
                .setTitle('Türk Asker Oyunu')
                .setURL(`https://www.roblox.com/games/${PLACE_ID}`)
                .setDescription(`🔹 **Mevcut Aktif Oyuncu Sayısı:** ${activePlayers} oyuncu`) // Açıklamaya taşı
                .setFooter({ text: 'Türk Asker Oyunu' })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Bir hata oluştu:', error);
            await interaction.reply({
                content: 'Oyunun bilgilerini alırken bir hata oluştu. Lütfen Universe ID\'yi kontrol edin.',
                ephemeral: true,
            });
        }
    },
};
