const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const noblox = require('noblox.js');
const rowifiRequest = require('../../Utils/rowifiRequest');
const config = require('../../config');
const autocomplete = require('../../Utils/autocomplete'); // utils/autocomplete.js dosyasını import ettik
const rateLimiter = require('../../Utils/rateLimiter'); 

const requiredRankId = 20;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rütbe-değiştir')
        .setDescription('Belirtilen kullanıcının rütbesini değiştirir.')
        .addStringOption(option =>
            option.setName('kullanıcı')
                .setDescription('Rütbesi değiştirilecek kullanıcının Roblox kullanıcı adı')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('rütbe')
                .setDescription('Yeni rütbe adı')
                .setRequired(true)
                .setAutocomplete(true) // Autocomplete özelliği aktif
        )
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Rütbe değişikliğinin sebebi')
                .setRequired(true)
        ),

    async execute(interaction) {
        const userId = interaction.user.id;

        const robloxUsername = interaction.options.getString('kullanıcı');
        const rankInput = interaction.options.getString('rütbe');
        const reason = interaction.options.getString('sebep');
        const discordUserId = interaction.user.id;
        const groupId = config.groupMain;
        const logChannelId = config.logChannelId;

        const { allowed, message } = rateLimiter.canUseCommand(discordUserId);  // Kullanıcı ID'sini gönderiyoruz
        if (!allowed) {
          return interaction.reply({ content: message, ephemeral: true });  // Limit aşılmamışsa mesaj gönderiyoruz
        }        

        // Sebep kontrolü: Minimum 3 karakter olmalı
        if (reason.length < 3) {
            return interaction.reply({
                content: '⚠️ Sebep en az 3 karakter uzunluğunda olmalıdır.',
                ephemeral: true,
            });
        }

        await interaction.deferReply();

        try {
            const rowifiData = await rowifiRequest(`/guilds/${interaction.guild.id}/members/${discordUserId}`);
            if (!rowifiData || !rowifiData.roblox_id) {
                return interaction.editReply({
                    content: `🚨 Bu komutu kullanabilmek için önce Discord hesabınızı Rowifi üzerinden Roblox hesabınıza bağlamanız gerekiyor.`
                });
            }

            const robloxUserId = rowifiData.roblox_id;

            const botUser = await noblox.setCookie(config.Cookie);
            if (!botUser) {
                throw new Error('Roblox botu giriş yapamadı. Lütfen config.Cookie değerini kontrol edin.');
            }

            const userRankId = await noblox.getRankInGroup(groupId, robloxUserId);
            const userRankName = await noblox.getRankNameInGroup(groupId, robloxUserId);

            if (userRankId < requiredRankId) {
                return interaction.editReply({
                    content: `🚨 Bu komutu kullanabilmek için grup içinde en az "${requiredRankId}" rütbe seviyesinde olmanız gerekiyor. Mevcut rütbeniz: \`${userRankName}\`.`
                });
            }

            const promoteRobloxUserId = await noblox.getIdFromUsername(robloxUsername).catch(() => null);
            if (!promoteRobloxUserId) {
                return interaction.editReply({
                    content: `⚠️ Kullanıcı adı "${robloxUsername}" geçerli değil veya kullanıcı bulunamadı.`
                });
            }

            const roles = await noblox.getRoles(groupId);
            const targetRole = roles.find(role => role.name.toLowerCase() === rankInput.toLowerCase());
            if (!targetRole) {
                return interaction.editReply({
                    content: `⚠️ "${rankInput}" adında bir rütbe bulunamadı. Lütfen doğru bir rütbe adı sağlayın.`
                });
            }

            const currentRankId = await noblox.getRankInGroup(groupId, promoteRobloxUserId);
            const currentRankName = await noblox.getRankNameInGroup(groupId, promoteRobloxUserId);

            if (currentRankId === targetRole.rank) {
                return interaction.editReply({
                    content: `⚠️ Kullanıcının mevcut rütbesi zaten "${rankInput}".`
                });
            }

            const promoteResponse = await noblox.setRank(groupId, promoteRobloxUserId, targetRole.rank);
            const updatedRankName = promoteResponse?.newRole?.name || await noblox.getRankNameInGroup(groupId, promoteRobloxUserId);

            const embed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setAuthor({ name: '✅ Rütbe Değişikliği Başarılı!', iconURL: interaction.client.user.displayAvatarURL({ dynamic: true, size: 512 }) })
                .addFields(
                    { name: '👤 Roblox Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },
                    { name: '📌 Eski Rütbe', value: `\`${currentRankName}\``, inline: true },
                    { name: '📈 Yeni Rütbe', value: `\`${updatedRankName}\``, inline: true },
                    { name: '📋 Sebep', value: reason, inline: false },
                )
                .setTimestamp();

            // Herkes tarafından görünür şekilde embed gönderiliyor
            await interaction.editReply({ embeds: [embed] });

            const logEmbed = new EmbedBuilder()
                .setColor('#ffcc00')
                .setAuthor({ name: '🔍 Rütbe Değişikliği Log', iconURL: interaction.client.user.displayAvatarURL({ dynamic: true, size: 512 }) })
                .addFields(
                    { name: '👤 Roblox Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },
                    { name: '📌 Eski Rütbe', value: `\`${currentRankName}\``, inline: true },
                    { name: '📈 Yeni Rütbe', value: `\`${updatedRankName}\``, inline: true },
                    { name: '🛠️ İşlem Yapan', value: interaction.member.displayName, inline: false },
                    { name: '📋 Sebep', value: reason, inline: false }
                )
                .setTimestamp();

            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.error('Rütbe değiştirme işlemi sırasında bir hata oluştu:', error);

            // Hata mesajları da artık herkes tarafından görülebilir
            await interaction.editReply({
                content: '⚠️ Bir hata oluştu. Lütfen daha sonra tekrar deneyin.'
            });
        }
    },

    async autocomplete(interaction) {
        // Burada sadece autocomplete işlemi yapılır, deferReply yapılmaz
        if (!interaction.isAutocomplete()) return; // autocomplete kontrolü
        await autocomplete(interaction);  // Bu işlemi, kendi autocomplete fonksiyonunuza göre bırakın
    },
};
