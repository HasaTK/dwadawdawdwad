const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const noblox = require('noblox.js');
const rowifiRequest = require('../../Utils/rowifiRequest'); // Rowifi API yardımcı dosyası

module.exports = {
    data: new SlashCommandBuilder()
        .setName('grup-listele')
        .setDescription('Belirtilen Roblox kullanıcısının bulunduğu grupları listeler.')
        .addStringOption(option =>
            option.setName('kullanıcı')
                .setDescription('Grupları listelenecek Roblox kullanıcı adı')
                .setRequired(true)
        ),

    async execute(interaction) {
        const robloxUsername = interaction.options.getString('kullanıcı');
        const groupIdToCheck = 13693196; // Kontrol edilecek grup ID'si
        const requiredRankId = 20; // Minimum gerekli rütbe ID

        await interaction.deferReply(); // İşlemin sürdüğünü bildir

        try {
            // Komutu kullanan kişinin Roblox ID'sini Rowifi API ile al
            const rowifiData = await rowifiRequest(`/guilds/${interaction.guild.id}/members/${interaction.user.id}`);
            if (!rowifiData || !rowifiData.roblox_id) {
                return interaction.editReply({
                    content: `⚠️ Bu komutu kullanabilmek için önce Discord hesabınızı Rowifi üzerinden Roblox hesabınıza bağlamanız gerekiyor.`,
                    ephemeral: true,
                });
            }

            const robloxUserId = rowifiData.roblox_id;

            // Kullanıcının gruptaki rütbesini kontrol et
            const userRankId = await noblox.getRankInGroup(groupIdToCheck, robloxUserId);
            if (userRankId < requiredRankId) {
                return interaction.editReply({
                    content: `🚨 Bu komutu kullanmak için "${groupIdToCheck}" grubundaki rütbenizin en az ID ${requiredRankId} olması gerekiyor. Şu anki rütbe ID'niz: ${userRankId}.`,
                    ephemeral: true,
                });
            }

            // Kullanıcının gruplarını al
            const targetRobloxUserId = await noblox.getIdFromUsername(robloxUsername).catch(() => null);

            if (!targetRobloxUserId) {
                return interaction.editReply({
                    content: `⚠️ Kullanıcı adı "${robloxUsername}" geçerli değil veya kullanıcı bulunamadı.`,
                    ephemeral: true,
                });
            }

            const groups = await noblox.getGroups(targetRobloxUserId);

            if (!groups.length) {
                return interaction.editReply({
                    content: `👤 "${robloxUsername}" kullanıcısı hiçbir grupta bulunmuyor.`,
                    ephemeral: true,
                });
            }

            // Grupları bölerek profesyonel bir embed olarak listele
            const embeds = [];
            for (let i = 0; i < groups.length; i += 25) {
                const groupSlice = groups.slice(i, i + 25);
                const embed = new EmbedBuilder()
                    .setColor('#1E90FF')
                    .setTitle(`${robloxUsername} Kullanıcısının Grupları`)
                    .setDescription(`Aşağıda **${robloxUsername}** kullanıcısının bulunduğu gruplar listelenmiştir:`)
                    .setThumbnail(`https://www.roblox.com/bust-thumbnail/image?userId=${targetRobloxUserId}&width=420&height=420&format=png`)
                    .setFooter({ text: `Sayfa ${Math.floor(i / 25) + 1}`, iconURL: 'https://static.rbxcdn.com/images/roblox.png' })
                    .setTimestamp();

                groupSlice.forEach(group => {
                    embed.addFields({
                        name: ` ${group.Name}`,
                        value: `** ID:** ${group.Id}\n** Rütbe:** ${group.Role}`,
                        inline: false
                    });
                });

                embeds.push(embed);
            }

            await interaction.editReply({ embeds });
        } catch (error) {
            console.error('Grup listeleme sırasında bir hata oluştu:', error);

            await interaction.editReply({
                content: '⚠️ Bir hata oluştu. Lütfen daha sonra tekrar deneyin.',
                ephemeral: true,
            });
        }
    },
};