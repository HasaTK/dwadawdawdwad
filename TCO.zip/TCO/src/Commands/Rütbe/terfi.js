const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const noblox = require('noblox.js');
const rowifiRequest = require('../../Utils/rowifiRequest'); // Rowifi API yardımcı dosyası
const config = require('../../config'); // Config dosyasından cookie ve grup bilgisi alınır.
const rateLimiter = require('../../Utils/rateLimiter');  // rateLimiter'ı dahil ettik


module.exports = {
    data: new SlashCommandBuilder()
        .setName('terfi')
        .setDescription('Belirtilen kullanıcının Roblox grubundaki rütbesini bir kademe yükseltir.')
        .addStringOption(option =>
            option.setName('kullanıcı')
                .setDescription('Terfi ettirilecek kullanıcının Roblox kullanıcı adı')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Terfi işleminin sebebi')
                .setRequired(true)
        ),

    async execute(interaction) {
        const robloxUsername = interaction.options.getString('kullanıcı'); // Terfi ettirilecek kullanıcı adı
        const reason = interaction.options.getString('sebep'); // Terfi sebebi
        const groupId = config.groupMain; // Grup ID'si
        const discordUserId = interaction.user.id; // Komutu kullanan Discord kullanıcısının ID'si
        const requiredRankId = 20; // Minimum gerekli rütbe ID'si

        const { allowed, message } = rateLimiter.canUseCommand(discordUserId);  // Kullanıcı ID'sini gönderiyoruz
        if (!allowed) {
          return interaction.reply({ content: message, ephemeral: true });  // Limit aşılmamışsa mesaj gönderiyoruz
        }

        if (reason.length < 3) {
            return interaction.reply({
                content: '⚠️ Sebep en az 3 karakter uzunluğunda olmalıdır.',
                ephemeral: true,
            });
        }

        await interaction.deferReply(); // Kullanıcıya işlem yapıldığını bildir

        try {
            // Rowifi API ile komutu kullanan kişinin Roblox hesabını doğrula
            const rowifiData = await rowifiRequest(`/guilds/${interaction.guild.id}/members/${discordUserId}`);
            if (!rowifiData || !rowifiData.roblox_id) {
                return interaction.editReply({
                    content: `🚨 Bu komutu kullanabilmek için önce Discord hesabınızı Rowifi üzerinden Roblox hesabınıza bağlamanız gerekiyor.`,
                    ephemeral: true,
                });
            }

            const robloxUserId = rowifiData.roblox_id; // Komutu kullananın Roblox ID'si

            // Kullanıcının mevcut rütbesini kontrol et
            const userCurrentRankId = await noblox.getRankInGroup(groupId, robloxUserId);
            const userCurrentRankName = await noblox.getRankNameInGroup(groupId, robloxUserId); // Rütbe adı
            if (userCurrentRankId === 0) {
                return interaction.editReply({
                    content: '⚠️ Roblox hesabınız belirtilen gruba üye değil. Bu komutu kullanamazsınız.',
                    ephemeral: true,
                });
            }

            if (userCurrentRankId < requiredRankId) {
                return interaction.editReply({
                    content: `⚠️ Bu komutu kullanmak için grubunuzdaki rütbenizin en az "**[OF-6] Tuğgeneral**" olması gerekiyor. Şu anki rütbeniz: "${userCurrentRankName}".`,
                    ephemeral: true,
                });
            }

            // Roblox botu giriş yapmaya çalışır
            const botUser = await noblox.setCookie(config.Cookie);
            if (!botUser) {
                throw new Error('Roblox botu giriş yapamadı.');
            }
            console.log(`Roblox botu giriş yaptı: ${botUser.UserName}`);

            // Hedef kullanıcının Roblox ID'sini al
            const promoteRobloxUserId = await noblox.getIdFromUsername(robloxUsername).catch(() => null);
            if (!promoteRobloxUserId) {
                return interaction.editReply({
                    content: `⚠️ Kullanıcı adı "${robloxUsername}" geçerli değil veya kullanıcı bulunamadı.`,
                    ephemeral: true,
                });
            }

            // Hedef kullanıcının mevcut rütbesini kontrol et
            const promoteCurrentRankId = await noblox.getRankInGroup(groupId, promoteRobloxUserId);
            const promoteCurrentRankName = await noblox.getRankNameInGroup(groupId, promoteRobloxUserId); // Rütbe adı

            if (promoteCurrentRankId === 0) {
                return interaction.editReply({
                    content: `⚠️ Bu kullanıcı (${robloxUsername}) belirtilen gruba üye değil.`,
                    ephemeral: true,
                });
            }

            // Eğer hedef kullanıcının rütbesi komutu kullananın rütbesine eşit veya büyükse, işlem yapılmasın
            if (promoteCurrentRankId >= userCurrentRankId) {
                return interaction.editReply({
                    content: `⚠️ Hedef kullanıcının rütbesi (${promoteCurrentRankName}) sizin rütbenize (${userCurrentRankName}) eşit veya daha yüksek. Bu işlemi gerçekleştiremezsiniz.`,
                    ephemeral: true,
                });
            }

            // Kullanıcıyı terfi ettir
            const promoteResponse = await noblox.promote(groupId, promoteRobloxUserId);
            const newRankName = promoteResponse.newRole.name; // Yeni rütbe bilgisi alınır

            // Başarı mesajını oluştur
            const botAvatarURL = interaction.client.user.displayAvatarURL({ dynamic: true, size: 512 });
            const guildIconURL = interaction.guild.iconURL({ dynamic: true, size: 512 }) || 'https://i.imgur.com/zgARxNj.png';
            const embed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setAuthor({ name: '✅ Terfi İşlemi Başarılı!', iconURL: guildIconURL })
                .setThumbnail(botAvatarURL)
                .addFields(
                    { name: '👤 Roblox Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },
                    { name: '📌 Önceki Rütbe', value: `\`${promoteCurrentRankName}\``, inline: true },
                    { name: '📌 Yeni Rütbe', value: `\`${newRankName}\``, inline: true },
                    { name: '📋 Sebep', value: reason, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: `${interaction.guild.name} - ${rowifiData.roblox_username}`, iconURL: guildIconURL });

            await interaction.editReply({ embeds: [embed] });

            // Log işlemi aynı şekilde devam eder
            const logChannelId = config.logChannelId || '1250919848997945364';
            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor('#33ef5a')
                    .setAuthor({ name: '🔼 Terfi İşlemi Log', iconURL: guildIconURL })
                    .addFields(
                        { name: '👤 Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },
                        { name: '📌 Önceki Rütbe', value: `\`${promoteCurrentRankName}\``, inline: true },
                        { name: '📌 Yeni Rütbe', value: `\`${newRankName}\``, inline: true },
                        { name: '🛠️ İşlem Yapan', value: rowifiData.roblox_username || interaction.member.displayName, inline: false },
                        { name: '📋 Sebep', value: reason, inline: false }
                    )
                    .setTimestamp()
                    .setFooter({ text: `${interaction.guild.name}`, iconURL: guildIconURL });

                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.error('Terfi işlemi sırasında bir hata oluştu:', error);
            await interaction.editReply({
                content: '⚠️ Bir hata oluştu. Lütfen daha sonra tekrar deneyin veya bot yapılandırmanızı kontrol edin.',
                ephemeral: true,
            });
        }
    },
};
