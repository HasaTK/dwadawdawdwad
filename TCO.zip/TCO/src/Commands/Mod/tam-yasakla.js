const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tam-yasakla')
        .setDescription('Belirtilen kullanıcıyı botun bulunduğu tüm sunuculardan yasaklar.')
        .addUserOption(option =>
            option.setName('kullanıcı')
                .setDescription('Yasaklanacak kullanıcıyı seçin')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Yasaklama nedeni (isteğe bağlı)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('id')
                .setDescription('Yasaklanacak kullanıcının Discord ID\'si')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    async execute(interaction) {
        let user = interaction.options.getUser('kullanıcı');
        const reason = interaction.options.getString('sebep') || 'Belirtilmedi';
        const userId = interaction.options.getString('id');

        if (userId) {
            user = await interaction.client.users.fetch(userId).catch(() => null);
            if (!user) {
                return interaction.reply({ content: 'Geçersiz kullanıcı ID\'si.', ephemeral: false });
            }
        }

        if (!user) {
            return interaction.reply({ content: 'Lütfen bir kullanıcı seçin veya geçerli bir ID girin.', ephemeral: false });
        }

        const allowedRoleIds = ['1233769721896374282', '1238434536061145130', '1247545981780627486', '1233879749043159202', '1234583107676405780'];
        const member = interaction.member;
        const hasAllowedRole = allowedRoleIds.some(roleId => member.roles.cache.has(roleId));
        if (!hasAllowedRole) {
            return interaction.reply({ content: 'Bu komutu kullanma izniniz yok.', ephemeral: false });
        }

        try {
            await interaction.deferReply({ ephemeral: false });

            const guilds = interaction.client.guilds.cache;
            const bannedGuilds = [];

            const dmEmbed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('⚠️ Yasaklandınız')
                .setDescription(`Tüm **TCO**sunuculardan yasaklandınız.\n\n**Sebep:** ${reason}\n**Yasaklayan:** ${interaction.user.tag}`)
                .setTimestamp();

            await user.send({ embeds: [dmEmbed] }).catch(() => {
                console.log(`${user.tag} adlı kullanıcıya DM gönderilemedi.`);
            });

            for (const guild of guilds.values()) {
                try {
                    // Sunucuda olup olmadığına bakmadan yasaklama işlemini gerçekleştir
                    await guild.bans.create(user.id, { reason });
                    bannedGuilds.push(guild.name);
                } catch (error) {
                    console.error(`Sunucu ${guild.name} üzerinde yasaklama işlemi yapılırken hata oluştu:`, error);
                }
            }

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('İşlem Başarıyla Gerçekleşti')
                .setDescription(`${user.tag} adlı kullanıcı tüm **TCO** sunucularından yasaklandı.`)
                .addFields(
                    { name: 'Sebep', value: reason, inline: true },
                    { name: 'Yasaklanan Sunucular', value: bannedGuilds.join('\n') || 'Yok', inline: false }
                )
                .setTimestamp()
                .setFooter({ text: `İşlem yapan: ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

            await interaction.editReply({ embeds: [embed], ephemeral: false });

            const logChannelId = '1233770062217740290';
            const logChannel = interaction.guild.channels.cache.get(logChannelId);

            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('Kullanıcı Yasaklandı')
                    .setDescription(`${user.tag} adlı kullanıcı tüm **TCO** sunucularından yasaklandı.`)
                    .addFields(
                        { name: 'Sebep', value: reason, inline: true },
                        { name: 'Yasaklayan Yetkili', value: interaction.user.tag, inline: true },
                        { name: 'Yasaklanan Sunucular', value: bannedGuilds.join('\n') || 'Yok', inline: false }
                    )
                    .setTimestamp()
                    .setFooter({ text: 'Log Mesajı', iconURL: interaction.client.user.displayAvatarURL() });

                await logChannel.send({ embeds: [logEmbed] });
            } else {
                console.warn('Log kanalı bulunamadı.');
            }
        } catch (error) {
            console.error(error);
            await interaction.editReply({ content: 'Bir hata oluştu. Lütfen daha sonra tekrar deneyin.', ephemeral: false });
        }
    },
};
