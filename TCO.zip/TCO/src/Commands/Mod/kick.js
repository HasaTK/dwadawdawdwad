const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("kick")
        .setDescription("Belirtilen üyeyi sunucudan atar.")
        .setDefaultMemberPermissions(PermissionsBitField.Flags.KickMembers) // "Üyeleri Atma" yetkisi kontrolü
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Atılacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("neden")
                .setDescription("Atılma nedeni.")
                .setRequired(false)
        ),

    async execute(interaction) {
        // Kullanıcıyı ve nedeni al
        const user = interaction.options.getUser("kullanıcı");
        const reason = interaction.options.getString("neden") || "Neden belirtilmedi";

        try {
            const member = await interaction.guild.members.fetch(user.id);

            // Yetki kontrolü
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
                const noPermissionEmbed = new EmbedBuilder()
                    .setColor("#FF0000")
                    .setTitle("🚫 Yetki Hatası")
                    .setDescription("Bu komutu kullanmak için **Üyeleri Atma** yetkiniz yok.")
                    .setTimestamp();

                return interaction.reply({ embeds: [noPermissionEmbed], ephemeral: true });
            }

            // Üyeyi at
            await member.kick(reason);

            // Kullanıcıya DM gönder
            const dmEmbed = new EmbedBuilder()
                .setColor("#FF4500")
                .setTitle(`⚠️ ${interaction.guild.name} Sunucusundan Atıldınız!`)
                .setDescription(`**Sebep:** ${reason}\n\nEğer bu bir hata olduğunu düşünüyorsanız, sunucu yetkilileriyle iletişime geçin.`)
                .setTimestamp();

            await user.send({ embeds: [dmEmbed] }).catch(() => {
                console.log(`Kullanıcı (${user.tag}) DM alamıyor.`);
            });

            // Başarılı işlem mesajı
            const embed = new EmbedBuilder()
                .setColor("#00FF00")
                .setTitle("✅ Kullanıcı Atıldı!")
                .setDescription(`**Kullanıcı:** ${user} (${user.tag})\n` +
                                `**Sebep:** ${reason}\n` +
                                `**Atan:** ${interaction.user.tag}`)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setFooter({ text: "Kick İşlemi Tamamlandı", iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } catch (error) {
            console.error(error);

            // Hata mesajı
            const errorEmbed = new EmbedBuilder()
                .setColor("#FF0000")
                .setTitle("❌ Bir hata oluştu!")
                .setDescription(`${user.username} kullanıcısını atamazsınız. Kullanıcının yetkisi yüksek olabilir ya da botun yetkisi yetersiz.`)
                .setFooter({ text: "Hata Kodu: 403", iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            await interaction.reply({
                embeds: [errorEmbed],
                ephemeral: true, // Hata mesajı sadece komutu kullanan kişiye görünür olacak
            });
        }
    },
};
