const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("ban")
        .setDescription("Belirtilen üyeyi sunucudan banlar.")
        .setDefaultMemberPermissions(PermissionsBitField.Flags.BanMembers) // "Üyeleri Banlama" yetkisi kontrolü
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Banlanacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("sebep")
                .setDescription("Banlanma sebebini belirtin.")
                .setRequired(false)
        ),

    async execute(interaction) {
        const user = interaction.options.getUser("kullanıcı"); // Banlanacak kullanıcı
        const reason = interaction.options.getString("sebep") || "Sebep belirtilmedi"; // Ban sebebi

        // Yetki kontrolü
        if (!interaction.memberPermissions.has(PermissionsBitField.Flags.BanMembers)) {
            const noPermissionEmbed = new EmbedBuilder()
                .setColor("#FF0000")
                .setTitle("🚫 Yetki Hatası")
                .setDescription("Bu komutu kullanmak için **Üyeleri Banlama** yetkiniz yok.")
                .setTimestamp();

            return interaction.reply({ embeds: [noPermissionEmbed], ephemeral: true });
        }

        try {
            const member = await interaction.guild.members.fetch(user.id); // Kullanıcı sunucuda var mı?

            // Kullanıcıyı banla
            await member.ban({ reason });

            // Başarılı işlem mesajı
            const successEmbed = new EmbedBuilder()
                .setColor("#00FF00")
                .setTitle("✅ Kullanıcı Banlandı!")
                .setDescription(`**Kullanıcı:** ${user} (${user.tag})\n` +
                                `**Banlayan:** ${interaction.user.tag}\n` +
                                `**Sebep:** ${reason}`)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setFooter({ text: "Ban işlemi tamamlandı", iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            const dmEmbed = new EmbedBuilder()
                .setColor("#FF4500")
                .setTitle(`⚠️ ${interaction.guild.name} Sunucusundan Banlandınız!`)
                .setDescription(`**Sebep:** ${reason}\n\nEğer bu işlemin bir hata olduğunu düşünüyorsanız sunucu yetkilileri ile iletişime geçebilirsiniz.`)
                .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                .setTimestamp();

            // Kullanıcıya DM gönder
            await member.send({ embeds: [dmEmbed] }).catch(() => {
                console.log(`Kullanıcı (${user.tag}) DM alamıyor.`);
            });

            // Komutu çalıştıran kişiye yanıt
            await interaction.reply({ embeds: [successEmbed] });
        } catch (error) {
            console.error(error);

            // Eğer hata oluştuysa kullanıcıya hata mesajı gönder
            const errorEmbed = new EmbedBuilder()
                .setColor("#FF0000")
                .setTitle("❌ Hata!")
                .setDescription(`**${user.tag}** kullanıcısını banlayamıyorum. Kullanıcının yetkisi yüksek olabilir ya da botun yetkisi yetersiz.`)
                .setFooter({ text: "Hata Kodu: 403", iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            await interaction.reply({
                embeds: [errorEmbed],
                ephemeral: true,
            });
        }
    },
};
