const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("clear")
        .setDescription("Belirtilen miktarda mesajı siler.")
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageMessages) // Sadece mesajları yönetme izni olanlar kullanabilir
        .addIntegerOption(option =>
            option
                .setName("sayı")
                .setDescription("Silinecek mesaj sayısını girin (1-300).")
                .setRequired(true) // Bu seçenek zorunludur
                .setMinValue(1) // Minimum değer 1
                .setMaxValue(300) // Maksimum değer 300
        ),

    async execute(interaction) {
        const { channel, options, member } = interaction;
        const amount = options.getInteger("sayı");

        // Yetki kontrolü
        if (!member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            const noPermissionEmbed = new EmbedBuilder()
                .setColor("Red")
                .setTitle("Yetki Hatası")
                .setDescription("Bu komutu kullanmak için **Mesajları Yönetme** yetkiniz yok.")
                .setTimestamp();

            return interaction.reply({ embeds: [noPermissionEmbed], ephemeral: true });
        }

        try {
            // 14 günden eski mesajlar kontrol edilir
            const deletedMessages = await channel.bulkDelete(amount, true);
            if (deletedMessages.size === 0) {
                return await interaction.reply({
                    content: "14 günden eski mesajlar silinemez. Daha yakın tarihli mesajlar seçin.",
                    ephemeral: true,
                });
            }

            // Başarılı işlem için embed
            const embed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("Mesajları Silme İşlemi Başarılı!")
                .setDescription(`✅ **${deletedMessages.size}** mesaj başarıyla silindi!`)
                .setTimestamp();

            await interaction.reply({ embeds: [embed], ephemeral: true });
        } catch (error) {
            console.error(error); // Hata günlüğe yazılır

            // Kullanıcıya hata bilgisi gösterilir
            await interaction.reply({
                content: "Mesajlar silinirken bir hata oluştu. Botun yeterli izne sahip olduğundan emin olun.",
                ephemeral: true,
            });
        }
    },
};
