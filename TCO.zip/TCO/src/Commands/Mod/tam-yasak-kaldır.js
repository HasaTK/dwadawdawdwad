const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tam-yasak-kaldir')
        .setDescription('Belirtilen Discord ID\'sine sahip kullanıcının botun bulunduğu tüm sunuculardan yasaklarını kaldırır.')
        .addStringOption(option =>
            option.setName('id')
                .setDescription('Yasak kaldırılacak kullanıcının Discord ID\'si')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Yasak kaldırma nedeni (isteğe bağlı)')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

    async execute(interaction) {
        const userId = interaction.options.getString('id');
        const reason = interaction.options.getString('sebep') || 'Belirtilmedi';

        let user;
        try {
            user = await interaction.client.users.fetch(userId);
        } catch {
            return interaction.reply({ content: 'Geçersiz kullanıcı ID\'si.', ephemeral: true });
        }

        if (!user) {
            return interaction.reply({ content: 'Kullanıcı bulunamadı.', ephemeral: true });
        }

        const allowedRoleIds = ['1233769721896374282', '1238434536061145130', '1247545981780627486', '1233879749043159202', '1234583107676405780','1331646273035698207'];
        const member = interaction.member;
        const hasAllowedRole = allowedRoleIds.some(roleId => member.roles.cache.has(roleId));
        if (!hasAllowedRole) {
            return interaction.reply({ content: 'Bu komutu kullanma izniniz yok.', ephemeral: true });
        }

        try {
            await interaction.deferReply({ ephemeral: false });

            const guilds = interaction.client.guilds.cache;
            const unbannedGuilds = [];

            // Botun bulunduğu tüm sunucularda yasak kaldırma işlemi
            for (const guild of guilds.values()) {
                try {
                    await guild.bans.fetch(userId).then(async () => {
                        await guild.bans.remove(userId, reason);
                        unbannedGuilds.push(guild.name);
                    }).catch(() => {
                        // Kullanıcı yasaklı değilse, bu sunucuyu atla
                    });
                } catch (error) {
                    console.error(`Sunucu ${guild.name} üzerinde yasak kaldırma işlemi yapılamadı:`, error);
                }
            }

            // Başarı Mesajı
            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('✅ Yasak Kaldırıldı')
                .setDescription(`${user.tag} adlı kullanıcının yasakları tüm sunuculardan kaldırıldı.`)
                .addFields(
                    { name: 'Sebep', value: reason, inline: true },
                    { name: 'Yasak Kaldırılan Sunucular', value: unbannedGuilds.join('\n') || 'Hiçbiri yok', inline: false }
                )
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setTimestamp()
                .setFooter({ text: `İşlem yapan: ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

            await interaction.editReply({ embeds: [embed], ephemeral: false });

            // Log Kanalına Mesaj
            const logChannelId = '1233770062217740290'; // Log kanal ID'si
            const logChannel = interaction.guild.channels.cache.get(logChannelId);

            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor('#FFFF00')
                    .setTitle('🔓 Yasak Kaldırıldı (Log)')
                    .setDescription(`${user.tag} adlı kullanıcının yasakları botun bulunduğu tüm sunuculardan kaldırıldı.`)
                    .addFields(
                        { name: 'Sebep', value: reason, inline: true },
                        { name: 'Yasak Kaldıran Yetkili', value: interaction.user.tag, inline: true },
                        { name: 'Yasak Kaldırılan Sunucular', value: unbannedGuilds.join('\n') || 'Hiçbiri yok', inline: false }
                    )
                    .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                    .setTimestamp()
                    .setFooter({ text: 'Log Mesajı', iconURL: interaction.client.user.displayAvatarURL() });

                await logChannel.send({ embeds: [logEmbed] });
            } else {
                console.warn('Log kanalı bulunamadı.');
            }
        } catch (error) {
            console.error(error);
            await interaction.editReply({ content: 'Bir hata oluştu. Lütfen daha sonra tekrar deneyin.', ephemeral: false });
        }
    },
};
