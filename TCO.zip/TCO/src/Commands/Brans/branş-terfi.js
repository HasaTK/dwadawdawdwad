const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const noblox = require('noblox.js');
const rowifiRequest = require('../../Utils/rowifiRequest');
const config = require('../../config');
const rateLimiter = require('../../Utils/rateLimiter');  // rateLimiter'ı dahil ettik

const branches = {
    "Askeri Inzibat Kuvvetleri": { groupId: config.groupAsiz, logChannelId: "1233770055121113098", requiredRankId: 14 },
    "Hava Kuvvetleri Komutanlığı": { groupId: config.groupHkk, logChannelId: "1233770051811803217", requiredRankId: 16 },
    "Özel Kuvvetler Komutanlığı": { groupId: config.groupOkk, logChannelId: "1234530438542921748", requiredRankId: 15 },
    "Jandarma Genel Komutanlığı": { groupId: config.groupJan, logChannelId: "1234530208711839754", requiredRankId: 16 },
    "Kara Kuvvetleri Komutanlığı": { groupId: config.groupKkk, logChannelId: "1233770048619937882", requiredRankId: 21 },
    "Sınır Müfettişleri": { groupId: config.groupSm, logChannelId: "1234530377146568814", requiredRankId: 15 },
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('brans-terfi')
        .setDescription('Belirtilen kullanıcının seçilen branştaki rütbesini bir kademe yükseltir.')
        .addStringOption(option =>
            option.setName('kullanıcı')
                .setDescription('Terfi ettirilecek kullanıcının Roblox kullanıcı adı')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('brans')
                .setDescription('İşlem uygulanacak branş')
                .setRequired(true)
                .addChoices(
                    ...Object.keys(branches).map(branch => ({ name: branch, value: branch }))
                )
        )
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Terfi işleminin sebebi')
                .setRequired(true)
        ),

    async execute(interaction) {
        const robloxUsername = interaction.options.getString('kullanıcı');
        const branchName = interaction.options.getString('brans');
        const reason = interaction.options.getString('sebep');
        const discordUserId = interaction.user.id;

        const branchData = branches[branchName];
        const branchGroupId = branchData.groupId;
        const logChannelId = branchData.logChannelId;
        const requiredRankId = branchData.requiredRankId;

        const { allowed, message } = rateLimiter.canUseCommand(discordUserId);  // Kullanıcı ID'sini gönderiyoruz
        if (!allowed) {
          return interaction.reply({ content: message, ephemeral: true });  // Limit aşılmamışsa mesaj gönderiyoruz
        }

        if (reason.length < 3) {
            return interaction.reply({
                content: '⚠️ Sebep en az 3 karakter uzunluğunda olmalıdır.',
                ephemeral: true,
            });
        }

        await interaction.deferReply();

        try {
            const rowifiData = await rowifiRequest(`/guilds/${interaction.guild.id}/members/${discordUserId}`);
            if (!rowifiData || !rowifiData.roblox_id) {
                return interaction.editReply({
                    content: `🚨 Bu komutu kullanabilmek için önce Discord hesabınızı Rowifi üzerinden Roblox hesabınıza bağlamanız gerekiyor.`,
                    ephemeral: true,
                });
            }

            const robloxUserId = rowifiData.roblox_id;

            const userCurrentRankId = await noblox.getRankInGroup(branchGroupId, robloxUserId);
            const userCurrentRankName = await noblox.getRankNameInGroup(branchGroupId, robloxUserId);

            if (userCurrentRankId === 0) {
                return interaction.editReply({
                    content: '⚠️ Roblox hesabınız belirtilen gruba üye değil.',
                    ephemeral: true,
                });
            }

            const ranks = await noblox.getRoles(branchGroupId);
            const requiredRank = ranks.find(rank => rank.rank === requiredRankId);
            if (!requiredRank) {
                console.error(`Gerekli Rütbe Bulunamadı: ID ${requiredRankId}`);
                return interaction.editReply({
                    content: `⚠️ Gerekli rütbe alınamadı. Lütfen sistem yöneticinize başvurun.`,
                    ephemeral: true,
                });
            }

            const requiredRankName = requiredRank.name;

            if (userCurrentRankId < requiredRankId) {
                return interaction.editReply({
                    content: `⚠️ Bu komutu kullanmak için branşınızdaki rütbenizin en az "**${requiredRankName}**" olması gerekiyor. Şu anki rütbeniz: "**${userCurrentRankName}**".`,
                    ephemeral: true,
                });
            }

            const botUser = await noblox.setCookie(config.Cookie);

            const promoteRobloxUserId = await noblox.getIdFromUsername(robloxUsername).catch(() => null);
            if (!promoteRobloxUserId) {
                return interaction.editReply({
                    content: `⚠️ Kullanıcı adı "${robloxUsername}" geçerli değil veya kullanıcı bulunamadı.`,
                    ephemeral: true,
                });
            }

            const promoteCurrentRankId = await noblox.getRankInGroup(branchGroupId, promoteRobloxUserId);
            const promoteCurrentRankName = await noblox.getRankNameInGroup(branchGroupId, promoteRobloxUserId);

            if (promoteCurrentRankId === 0) {
                return interaction.editReply({
                    content: `⚠️ Bu kullanıcı (${robloxUsername}) belirtilen branş grubuna üye değil.`,
                    ephemeral: true,
                });
            }

            if (promoteCurrentRankId >= userCurrentRankId) {
                return interaction.editReply({
                    content: `⚠️ Hedef kullanıcının rütbesi (${promoteCurrentRankName}) sizin rütbenize (${userCurrentRankName}) eşit veya daha yüksek.`,
                    ephemeral: true,
                });
            }

            const promoteResponse = await noblox.promote(branchGroupId, promoteRobloxUserId);
            const newRankName = promoteResponse.newRole.name;

            const botAvatarURL = interaction.client.user.displayAvatarURL({ dynamic: true, size: 512 });

            const guildIconURL = interaction.guild.iconURL({ dynamic: true, size: 512 }) || 'https://i.imgur.com/zgARxNj.png';

            const embed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setAuthor({ name: '✅ Branş Terfi İşlemi Başarılı!' })
                .setThumbnail(botAvatarURL)
                .addFields(
                    { name: '👤 Roblox Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },
                    { name: '📌 Önceki Rütbe', value: `\`${promoteCurrentRankName}\``, inline: true },
                    { name: '📌 Yeni Rütbe', value: `\`${newRankName}\``, inline: true },
                    { name: '📋 Sebep', value: reason, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: `${interaction.guild.name} - ${rowifiData.roblox_username}`, iconURL: guildIconURL });

            await interaction.editReply({ embeds: [embed] });

            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor('#33ef5a')
                    .setAuthor({ name: '🔼 Branş Terfi Log' })
                    .setThumbnail(botAvatarURL)
                    .addFields(
                        { name: '👤 Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },
                        { name: '📌 Önceki Rütbe', value: `\`${promoteCurrentRankName}\``, inline: true },
                        { name: '📌 Yeni Rütbe', value: `\`${newRankName}\``, inline: true },
                        { name: '🛠️ İşlem Yapan', value: rowifiData.roblox_username || interaction.member.displayName, inline: false },
                        { name: '📋 Sebep', value: reason, inline: false }
                    )
                    .setTimestamp()
                    .setFooter({ text: `${interaction.guild.name}`, iconURL: guildIconURL });

                await logChannel.send({ embeds: [logEmbed] });
            } else {
                console.error(`Belirtilen log kanalı bulunamadı: ${logChannelId}`);
            }
        } catch (error) {
            console.error('Branş terfi işlemi sırasında bir hata oluştu:', error);

            await interaction.editReply({
                content: '⚠️ Bir hata oluştu. Lütfen daha sonra tekrar deneyin.',
                ephemeral: true,
            });
        }
    },
};
