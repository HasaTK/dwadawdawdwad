const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const noblox = require('noblox.js');
const rowifiRequest = require('../../Utils/rowifiRequest'); // Rowifi API yardımcı dosyası
const config = require('../../config'); // Config dosyasından cookie ve grup bilgisi alınır.

const branches = {
    "Askeri Inzibat Kuvvetleri": { groupId: config.groupAsiz, logChannelId: "1233770055121113098", requiredRankId: 14 },
    "Hava Kuvvetleri Komutanlığı": { groupId: config.groupHkk, logChannelId: "1233770051811803217", requiredRankId: 16 },
    "Özel Kuvvetler Komutanlığı": { groupId: config.groupOkk, logChannelId: "1234530438542921748", requiredRankId: 15 },
    "Jandarma Genel Komutanlığı": { groupId: config.groupJan, logChannelId: "1234530208711839754", requiredRankId: 16 },
    "Kara Kuvvetleri Komutanlığı": { groupId: config.groupKkk, logChannelId: "1233770048619937882", requiredRankId: 21 },
    "Sınır Müfettişleri": { groupId: config.groupSm, logChannelId: "1234530377146568814", requiredRankId: 15 },
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('brans-istek')
        .setDescription('Belirtilen kullanıcı için grup katılma isteğini onaylar.')
        .addStringOption(option =>
            option.setName('kullanıcı')
                .setDescription('Katılma isteği onaylanacak Roblox kullanıcı adı')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('brans')
                .setDescription('İşlem uygulanacak branş')
                .setRequired(true)
                .addChoices(
                    ...Object.keys(branches).map(branch => ({ name: branch, value: branch }))
                )
        )
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Katılma isteği onaylama sebebi')
                .setRequired(true)
        ),

    async execute(interaction) {
        const robloxUsername = interaction.options.getString('kullanıcı');
        const branchName = interaction.options.getString('brans');
        const reason = interaction.options.getString('sebep');
        const discordUserId = interaction.user.id;

        const branchData = branches[branchName];
        const branchGroupId = branchData.groupId;
        const logChannelId = branchData.logChannelId;
        const requiredRankId = branchData.requiredRankId;

        if (reason.length < 3) {
            return interaction.reply({
                content: '⚠️ Sebep en az 3 karakter uzunluğunda olmalıdır.',
                ephemeral: true,
            });
        }

        await interaction.deferReply();

        try {
            const rowifiData = await rowifiRequest(`/guilds/${interaction.guild.id}/members/${discordUserId}`);
            if (!rowifiData || !rowifiData.roblox_id) {
                return interaction.editReply({
                    content: `🚨 Bu komutu kullanabilmek için önce Discord hesabınızı Rowifi üzerinden Roblox hesabınıza bağlamanız gerekiyor.`,
                    ephemeral: true,
                });
            }

            const robloxUserId = rowifiData.roblox_id;

            const userCurrentRankId = await noblox.getRankInGroup(branchGroupId, robloxUserId);
            const userCurrentRankName = await noblox.getRankNameInGroup(branchGroupId, robloxUserId);

            if (userCurrentRankId === 0) {
                return interaction.editReply({
                    content: '⚠️ Roblox hesabınız belirtilen gruba üye değil. Bu komutu kullanamazsınız.',
                    ephemeral: true,
                });
            }

            if (userCurrentRankId < requiredRankId) {
                return interaction.editReply({
                    content: `⚠️ Bu komutu kullanmak için branşınızdaki rütbenizin en az "**${requiredRankId}**" olması gerekiyor. Şu anki rütbeniz: "**${userCurrentRankName}**".`,
                    ephemeral: true,
                });
            }

            const botUser = await noblox.setCookie(config.Cookie);
            if (!botUser) {
                throw new Error('Roblox botu giriş yapamadı. Lütfen config.Cookie değerini kontrol edin.');
            }

            const joinRequests = await noblox.getJoinRequests(branchGroupId);
            if (!joinRequests || !Array.isArray(joinRequests.data)) {
                console.error('Katılma isteği verisi beklenilen formatta değil:', joinRequests);
                throw new Error('Katılma isteklerini alırken beklenmeyen bir hata oluştu.');
            }

            const request = joinRequests.data.find(req => req.requester.username.toLowerCase() === robloxUsername.toLowerCase());

            if (!request) {
                return interaction.editReply({
                    content: `⚠️ "${robloxUsername}" kullanıcısına ait bir katılma isteği bulunamadı.`,
                    ephemeral: true,
                });
            }

            await noblox.handleJoinRequest(branchGroupId, request.requester.userId, true);
            const botAvatarURL = interaction.client.user.displayAvatarURL({ dynamic: true, size: 512 });

            const embed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setAuthor({ name: '✅ Katılma İsteği Onaylandı!' })
                .setThumbnail(botAvatarURL) // Botun profil resmi
                .addFields(
                    { name: '👤 Roblox Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },
                    { name: '📋 Branş', value: branchName, inline: true },
                    { name: '📋 Sebep', value: reason, inline: false }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor('#33ef5a')
                    .setAuthor({ name: '🔍 Katılma İsteği Log' })
                    .addFields(
                        { name: '👤 Roblox Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },
                        { name: '📋 Branş', value: branchName, inline: true },
                        { name: '📋 Sebep', value: reason, inline: false },
                        { name: '🛠️ İşlem Yapan', value: interaction.member.displayName, inline: false }
                    )
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.error('Katılma isteği onaylama işlemi sırasında bir hata oluştu:', error);

            await interaction.editReply({
                content: '⚠️ Bir hata oluştu. Lütfen daha sonra tekrar deneyin.',
                ephemeral: true,
            });
        }
    },
};
