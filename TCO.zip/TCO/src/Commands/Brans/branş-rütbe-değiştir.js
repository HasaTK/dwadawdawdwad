const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const noblox = require('noblox.js');
const rowifiRequest = require('../../Utils/rowifiRequest'); // Rowifi API yardımcı dosyası
const config = require('../../config'); // Config dosyasından cookie ve grup bilgisi alınır.
const rateLimiter = require('../../Utils/rateLimiter');  // rateLimiter'ı dahil ettik

const branches = {
    "Askeri Inzibat Kuvvetleri": { groupId: config.groupAsiz, logChannelId: "1233770055121113098", requiredRankId: 14 },
    "Hava Kuvvetleri Komutanlığı": { groupId: config.groupHkk, logChannelId: "1233770051811803217", requiredRankId: 16 },
    "Özel Kuvvetler Komutanlığı": { groupId: config.groupOkk, logChannelId: "1234530438542921748", requiredRankId: 15 },
    "Jandarma Genel Komutanlığı": { groupId: config.groupJan, logChannelId: "1234530208711839754", requiredRankId: 16 },
    "Kara Kuvvetleri Komutanlığı": { groupId: config.groupKkk, logChannelId: "1233770048619937882", requiredRankId: 21 },
    "Sınır Müfettişleri": { groupId: config.groupSm, logChannelId: "1234530377146568814", requiredRankId: 15 },
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('brans-rütbe-değiştir')
        .setDescription('Belirtilen kullanıcının seçilen branştaki rütbesini değiştirir.')
        .addStringOption(option =>
            option.setName('kullanıcı')
                .setDescription('Rütbesi değiştirilecek kullanıcının Roblox kullanıcı adı')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('brans')
                .setDescription('İşlem uygulanacak branş')
                .setRequired(true)
                .addChoices(
                    ...Object.keys(branches).map(branch => ({ name: branch, value: branch }))
                )
        )
        .addStringOption(option =>
            option.setName('rütbe')
                .setDescription('Yeni rütbe adı (Branşa göre belirtilmeli)')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Rütbe değişikliğinin sebebi')
                .setRequired(true)
        ),

    async execute(interaction) {
        const robloxUsername = interaction.options.getString('kullanıcı');
        const branchName = interaction.options.getString('brans');
        const rankInput = interaction.options.getString('rütbe');
        const reason = interaction.options.getString('sebep');
        const discordUserId = interaction.user.id;

        const branchData = branches[branchName];
        const branchGroupId = branchData.groupId;
        const logChannelId = branchData.logChannelId;

        const { allowed, message } = rateLimiter.canUseCommand(discordUserId);  // Kullanıcı ID'sini gönderiyoruz
        if (!allowed) {
          return interaction.reply({ content: message, ephemeral: true });  // Limit aşılmamışsa mesaj gönderiyoruz
        }

        if (reason.length < 3) {
            return interaction.reply({
                content: '⚠️ Sebep en az 3 karakter uzunluğunda olmalıdır.',
                ephemeral: true,
            });
        }

        await interaction.deferReply();

        try {
            const rowifiData = await rowifiRequest(`/guilds/${interaction.guild.id}/members/${discordUserId}`);
            if (!rowifiData || !rowifiData.roblox_id) {
                return interaction.editReply({
                    content: `🚨 Bu komutu kullanabilmek için önce Discord hesabınızı Rowifi üzerinden Roblox hesabınıza bağlamanız gerekiyor.`,
                    ephemeral: true,
                });
            }

            const robloxUserId = rowifiData.roblox_id;

            const userCurrentRankId = await noblox.getRankInGroup(branchGroupId, robloxUserId);
            const userCurrentRankName = await noblox.getRankNameInGroup(branchGroupId, robloxUserId);

            if (userCurrentRankId === 0) {
                return interaction.editReply({
                    content: '⚠️ Roblox hesabınız belirtilen gruba üye değil. Bu komutu kullanamazsınız.',
                    ephemeral: true,
                });
            }

            const botUser = await noblox.setCookie(config.Cookie);
            if (!botUser) {
                throw new Error('Roblox botu giriş yapamadı. Lütfen config.Cookie değerini kontrol edin.');
            }

            const promoteRobloxUserId = await noblox.getIdFromUsername(robloxUsername).catch(() => null);
            if (!promoteRobloxUserId) {
                return interaction.editReply({
                    content: `⚠️ Kullanıcı adı "${robloxUsername}" geçerli değil veya kullanıcı bulunamadı.`,
                    ephemeral: true,
                });
            }

            // Mevcut rolleri alın ve doğrulama yap
            const roles = await noblox.getRoles(branchGroupId);
            const targetRole = roles.find(role => role.name.toLowerCase() === rankInput.toLowerCase());
            if (!targetRole) {
                return interaction.editReply({
                    content: `⚠️ "${rankInput}" adında bir rütbe bulunamadı. Lütfen doğru bir rütbe adı sağlayın.`,
                    ephemeral: true,
                });
            }

            const currentRankId = await noblox.getRankInGroup(branchGroupId, promoteRobloxUserId);
            const currentRankName = await noblox.getRankNameInGroup(branchGroupId, promoteRobloxUserId);

            // Eğer mevcut rütbe ile hedef rütbe aynıysa işlem yapılmasın
            if (currentRankId === targetRole.rank) {
                return interaction.editReply({
                    content: `⚠️ Kullanıcının mevcut rütbesi zaten "${rankInput}".`,
                    ephemeral: true,
                });
            }

            const promoteResponse = await noblox.setRank(branchGroupId, promoteRobloxUserId, targetRole.rank);

            const updatedRankName = promoteResponse?.newRole?.name || await noblox.getRankNameInGroup(branchGroupId, promoteRobloxUserId);

            const botAvatarURL = interaction.client.user.displayAvatarURL({ dynamic: true, size: 512 });

            // Sunucunun simgesini al
            const guildIconURL = interaction.guild.iconURL({ dynamic: true, size: 512 }) || 'https://i.imgur.com/zgARxNj.png';


            const embed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setAuthor({ name: '✅ Rütbe Değişikliği Başarılı!', iconURL: interaction.guild.iconURL({ dynamic: true, size: 512 }) })
                .setThumbnail(botAvatarURL) // Botun profil resmi
                .addFields(
                    { name: '👤 Roblox Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },    
                    { name: '📌 Eski Rütbe', value: `\`${currentRankName}\``, inline: true },
                    { name: '📈 Yeni Rütbe', value: `\`${updatedRankName}\``, inline: true },
                    { name: '📋 Sebep', value: reason, inline: false },
                )
                .setTimestamp()
                .setFooter({ text: `${interaction.guild.name} `, iconURL: guildIconURL });

            await interaction.editReply({ embeds: [embed] });

            // Log kanalı için embed
            const logEmbed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setAuthor({ name: '🔍 Rütbe Değişikliği Log', iconURL: interaction.guild.iconURL({ dynamic: true, size: 512 }) })
                .addFields(
                    { name: '👤 Roblox Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },
                    { name: '📌 Eski Rütbe', value: `\`${currentRankName}\``, inline: true },
                    { name: '📈 Yeni Rütbe', value: `\`${updatedRankName}\``, inline: true },
                    { name: '🛠️ İşlem Yapan', value: interaction.member.displayName, inline: false },
                    { name: '📋 Sebep', value: reason, inline: false }
                )
                .setTimestamp();

            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.error('Rütbe değiştirme işlemi sırasında bir hata oluştu:', error);

            await interaction.editReply({
                content: '⚠️ Bir hata oluştu. Lütfen daha sonra tekrar deneyin.',
                ephemeral: true,
            });
        }
    },
};