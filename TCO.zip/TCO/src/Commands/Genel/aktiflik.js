const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('aktif')
        .setDescription('Belirtilen hedef kanala aktiflik mesajı gönderir.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator), // Sadece yöneticiler kullanabilir

    async execute(interaction) {
        // Hedef kanal ID'sini burada belirtiyoruz
        const targetChannelId = '1327788505694208105'; // Buraya hedef kanal ID'sini yazın

        // Hedef kanalı sunucudan alıyoruz
        const targetChannel = interaction.guild.channels.cache.get(targetChannelId);

        // Hedef kanalın geçerli olup olmadığını kontrol ediyoruz
        if (!targetChannel || (targetChannel.type !== ChannelType.GuildText && targetChannel.type !== ChannelType.GuildAnnouncement)) {
            return interaction.reply({
                content: 'Hedef kanal bulunamadı veya geçerli bir metin kanalı değil.',
                ephemeral: true,
            });
        }

        // Mesaj içeriği
        const messageContent = `**Aktiflik Duyuru**\nAktif olan herkes oyuna bekleniyor!\nOyun Linki: https://www.roblox.com/tr/games/86644961278890/TCO-T-rk-Asker-Oyunu\nTag: @here`;

        try {
            // Mesaj gönder
            const sentMessage = await targetChannel.send(messageContent);

            // Eğer hedef kanal duyuru kanalıysa mesajı duyuru olarak yayınla
            if (targetChannel.type === ChannelType.GuildAnnouncement) {
                await sentMessage.crosspost(); // Duyuru olarak yayınlama
            }

            await interaction.reply({ content: 'Aktiflik mesajı başarıyla gönderildi!', ephemeral: true });
        } catch (error) {
            console.error('Mesaj gönderme hatası:', error);
            await interaction.reply({ content: 'Mesaj gönderilirken bir hata oluştu.', ephemeral: true });
        }
    },
};
