const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('duyuru-menusu')
        .setDescription('Eğitim duyurusu yapmak için kanal ve seçenekleri belirleyin.')
        .addChannelOption(option =>
            option.setName('kanal')
                .setDescription('Duyurunun gönderileceği kanalı seçin.')
                .setRequired(true)
        ),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return interaction.reply({ content: '⛔ Bu komutu kullanmak için gerekli yetkiye sahip değilsiniz.', ephemeral: true });
        }

        const channel = interaction.options.getChannel('kanal');
        if (!channel || channel.type !== 0) {
            return interaction.reply({ content: '⚠️ Geçersiz kanal seçimi. Lütfen bir metin kanalı seçin.', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📢 Eğitim Duyuru Menüsü')
            .setDescription('Eğitim duyurusu yapmak için aşağıdaki butona tıklayın ve ardından rütbe seçimini yapın. \n\n Test amacıyla kullanmak yasaktır. \n\n Eğitim yaparken eğitim duyuru atmanız zorunludur. ')
            .setImage('https://cdn.discordapp.com/attachments/1326211936160845905/1333822934061547562/1.png?ex=679a4ae8&is=6798f968&hm=f2447186f8c022cbe507af53b4f872cc745454b9d4a5294411cca4f51cda7604&')
            .setFooter({ text: 'Eğitim Menüsü' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('egitim_duyuru')
                    .setLabel('Eğitim Duyurusu Gönder')
                    .setStyle(ButtonStyle.Primary)
            );

        await interaction.reply({
            embeds: [embed],
            components: [row],
        });

        const filter = i => i.customId === 'egitim_duyuru';
        const collector = interaction.channel.createMessageComponentCollector({ filter });

        collector.on('collect', async i => {
            try {
                const requiredRoleIds = ['1233769816444371055', '1233769806499680328','1233769776875044927','1322629076946653194',"1234583107676405780","1233879749043159202","1247545981780627486","1238434536061145130","1238433131048992769","1238193223025950851","1233769721896374282"]; // Birden fazla gerekli rol ID'si
                const hasRequiredRole = requiredRoleIds.some(roleId => i.member.roles.cache.has(roleId));

                if (!hasRequiredRole) {
                    return i.reply({ content: '⛔ Bu işlemi gerçekleştirmek için gerekli role sahip olmanız gerekiyor.', ephemeral: true });
                }

                const rankMenu = new ActionRowBuilder()
                    .addComponents(
                        new StringSelectMenuBuilder()
                            .setCustomId('rank_selection')
                            .setPlaceholder('Bir rütbe seçin...')
                            .addOptions(
                                { label: 'OR-1', description: 'OR-1 için duyuru yap', value: 'OR-1' },
                                { label: 'OR-2', description: 'OR-2 için duyuru yap', value: 'OR-2' },
                                { label: 'OR-3+', description: 'OR-3+ için duyuru yap', value: 'OR-3' }
                            )
                    );

                await i.reply({ content: 'Lütfen bir rütbe seçin:', components: [rankMenu], ephemeral: true });

                const rankFilter = m => m.customId === 'rank_selection' && m.user.id === i.user.id;
                const rankCollector = i.channel.createMessageComponentCollector({ rankFilter, time: 30000 });

                rankCollector.on('collect', async rankInteraction => {
                    const selectedRank = rankInteraction.values[0];

                    const roleTags = {
                        'OR-1': ['<@&1233769845615755336>'], // OR-1 için rol ID'leri
                        'OR-2': ['<@&1233769843556225054>'], // OR-2 için rol ID'si
                        'OR-3': ['<@&1233769842142744587>', '<@&1233769840301572117>','<@&1233769839336882236>','<@&1233769834043543583>','<@&1233769833271922798>','<@&1233769831749259294>'], // OR-3+ için rol ID'leri
                    };

                    const taggedRoles = roleTags[selectedRank].join(' ');
                    const messageContent = `📢 **Eğitim Duyurusu**\n\nHost: <@${interaction.user.id}>\n\nOyunda ${selectedRank} eğitimi bulunmaktadır. İlgili personel oyuna beklenmektedir.\n\n**Oyun Linki:**\nhttps://www.roblox.com/tr/games/86644961278890/T-rk-Asker-Oyunu\n\n${taggedRoles}`;

                    const duyuruChannel = await interaction.client.channels.fetch('1329880272698871869'); // Duyuru kanalının ID'si
                    await duyuruChannel.send(messageContent);

                    await rankInteraction.reply({ content: `✅ ${selectedRank} rütbesi için eğitim duyurusu başarıyla gönderildi.`, ephemeral: true });
                });

                rankCollector.on('end', collected => {
                    if (collected.size === 0) {
                        i.followUp({ content: '⏰ Rütbe seçimi için süre doldu.', ephemeral: true });
                    }
                });
            } catch (error) {
                console.error('Hata oluştu:', error);
                await i.reply({ content: '⛔ Bir hata oluştu. Lütfen logları kontrol edin.', ephemeral: true });
            }
        });
    },
};
