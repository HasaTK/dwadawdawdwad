const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Botun gecikme sürelerini gösterir.'),
    async execute(interaction) {
        const sentMessage = await interaction.deferReply({ fetchReply: true });

        const apiLatency = Math.round(interaction.client.ws.ping);
        const messageLatency = sentMessage.createdTimestamp - interaction.createdTimestamp;

        const embed = new EmbedBuilder()
            .setColor('#1e90ff') // Göz alıcı bir mavi ton
            .setAuthor({ name: '⚡ Bot Performansı ⚡', iconURL: interaction.client.user.displayAvatarURL() })
            .setDescription('Aşağıda botun performans ölçümleri yer almaktadır:')
            .addFields(
                { name: '📡 WebSocket (WS) Gecikmesi:', value: `\`${apiLatency} ms\``, inline: true },
                { name: '💬 Mesaj Gecikmesi:', value: `\`${messageLatency} ms\``, inline: true },
                { name: '🔄 API Gecikmesi:', value: `\`${Math.abs(apiLatency - messageLatency)} ms\``, inline: true }
            )
            .setThumbnail(interaction.client.user.displayAvatarURL({ size: 512, dynamic: true }))
            .setFooter({ text: `İşlem ${interaction.user.tag} tarafından gerçekleştirildi`, iconURL: interaction.user.displayAvatarURL() })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    },
};
