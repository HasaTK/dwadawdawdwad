const { ActivityType, Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const noblox = require('noblox.js');
const consola = require('consola');
const AntiCrash = require('./Utils/Functions/AntiCrash.js');
const { embed } = require('./Utils/Functions/embed.js');
const config = require('./config.js'); // Config dosyasını buraya ekledik

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
    ],
    partials: [
        Partials.Message,
        Partials.Channel,
        Partials.Reaction,
    ],
    allowedMentions: {
        parse: ['users', 'roles'],
        repliedUser: true,
    },
    presence: {
        status: 'dnd', // Do Not Disturb olarak ayarlıyoruz
        activities: [
            {
                name: 'Realnqa Tarafından Yapılmıştır', // Durum mesajı
                type: ActivityType.Playing,
            },
        ],
    },
});

async function connectToRoblox() {
    try {
        const cookie = config.Cookie; // Config dosyasından çerez alınıyor
        await noblox.setCookie(cookie);

        const currentUser = await noblox.getAuthenticatedUser();
        consola.success(`✔ Başarıyla bağlanıldı! Giriş yapılan hesap: ${currentUser.name}`);
    } catch (error) {
        consola.error('Roblox bağlantı hatası:', error.message);
    }
}

connectToRoblox();

client.commands = new Collection();
client.context = new Collection();
client.config = config; // Config'i client üzerinde saklıyoruz
client.embed = embed;

// Komut yükleyici
require("./Utils/slashCommandsLoader.js")(client);

// Etkinlik yükleyici
require("./Utils/eventsLoader.js")(client);

// AntiCrash sistemi
AntiCrash();

// Hakkında kısmını değiştirecek bir dizi
const statusMessages = [
    'TCO | Türkiye Cumhuriyeti Ordusu',
    'Satın alım için realnqa DM gönderiniz.'
];

// 5 saniyede bir durumu değiştirecek fonksiyon
let currentStatusIndex = 0;

function updateStatus() {
    client.user.setPresence({
        status: 'dnd', // Durumun tipi: 'dnd' yani rahatsız etmeyin
        activities: [
            {
                name: statusMessages[currentStatusIndex], // Hakkında kısmını değiştirecek mesaj
                type: ActivityType.Playing, // Oynuyor olarak kalacak
            },
        ],
    });

    // Durumun indexini arttırarak bir sonraki durumu seçiyoruz.
    currentStatusIndex = (currentStatusIndex + 1) % statusMessages.length;
}

// Her 5 saniyede bir durumu güncelleme
setInterval(updateStatus, 5000);

// TEST KODU: Yüklü komutları konsola yazdırır
client.on('ready', () => {
    console.log('Yüklü Komutlar:');
    client.commands.forEach((cmd, name) => {
        console.log(`- ${name}`);
    });

    console.log('Yüklü Context Menüler:');
    client.context.forEach((ctx, name) => {
        console.log(`- ${name}`);
    });

    consola.success(`${client.user.tag} başarıyla giriş yaptı!`);
});

client.login(client.config.token);
