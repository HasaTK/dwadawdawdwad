const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("sustur-kaldir") // Komut adı
        .setDescription("Belirtilen üyenin susturmasını kaldırır.") // Komut açıklaması
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Susturması kaldırılacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("sebep")
                .setDescription("Susturmayı kaldırma sebebini yazın.")
                .setRequired(true)
        ),

    async execute(interaction) {
        const { guild, options, member } = interaction;

        await interaction.deferReply({ ephemeral: false }); // Herkese görünür yanıt

        const user = options.getUser('kullanıcı'); // İşlem yapılacak kullanıcı
        const reason = options.getString('sebep') || "Sebep belirtilmedi."; // Sebep
        const timeMember = guild.members.cache.get(user.id); // Sunucudaki kullanıcıyı al

        // İzin verilmiş rol ID'leri
        const allowedRoleIds = ['1233769721896374282', '1234583107676405780', '1233879749043159202', '1233769764376023120']; // Rol ID'leriniz
        const hasAllowedRole = allowedRoleIds.some(roleId => member.roles.cache.has(roleId));

        // Rol kontrolü
        if (!hasAllowedRole) {
            return await interaction.editReply({ content: "Bu komutu kullanma yetkiniz yok!" });
        }

        if (!timeMember) {
            return await interaction.editReply({ content: "Bu kullanıcı artık bu sunucuda değil!" });
        }

        if (!timeMember.communicationDisabledUntilTimestamp) {
            return await interaction.editReply({ content: `<@${user.id}> adlı kullanıcı zaten susturulmamış!` });
        }

        // Susturmayı kaldırma işlemi
        try {
            await timeMember.timeout(null, reason); // Susturmayı kaldırmak için `null` kullanılır
        } catch (error) {
            console.error(error);
            return await interaction.editReply({ content: "Susturma kaldırılırken bir hata oluştu." });
        }

        // Başarı mesajı (Herkese görünür)
        const embed = new EmbedBuilder()
            .setColor("Green")
            .setTitle("Susturma Kaldırıldı")
            .setDescription(
                `**Kullanıcı:** <@${user.id}> (${user.id})\n` +
                `**Sebep:** ${reason}\n` +
                `**İşlemi Yapan:** ${interaction.user.tag}`
            )
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        // Log kanalı
        const logChannelId = '1328411376951234682'; // Log kanalınızın ID'si
        const logChannel = guild.channels.cache.get(logChannelId);

        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("Susturma Kaldırıldı")
                .setDescription(
                    `**Kullanıcı:** ${timeMember.user.tag} (${timeMember.user.id})\n` +
                    `**Susturmayı Kaldıran:** ${interaction.user.tag} (${interaction.user.id})\n` +
                    `**Sebep:** ${reason}`
                )
                .setTimestamp();

            await logChannel.send({ embeds: [logEmbed] });
        }
    },
};
