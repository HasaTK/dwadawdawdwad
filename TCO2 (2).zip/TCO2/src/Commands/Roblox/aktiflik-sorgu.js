const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const noblox = require('noblox.js');

// Stabil Place ID (Bu ID değişmeyecek)
const PLACE_ID = 86644961278890; // Buraya istediğiniz Place ID'yi yazın

module.exports = {
    data: new SlashCommandBuilder()
        .setName('aktiflik-sorgu') // Komut adı
        .setDescription('Oyunun mevcut aktif oyuncu sayısını gösterir.'),

    async execute(interaction) {
        try {
            // Noblox.js kullanarak Place Info al
            const placeInfo = await noblox.getPlaceInfo([PLACE_ID]);

            // Yanıtı kontrol et
            if (!placeInfo || placeInfo.length === 0) {
                return interaction.reply({ content: 'Bu Place ID için bilgi bulunamadı!', ephemeral: true });
            }

            const gameData = placeInfo[0]; // İlk oyun bilgisi (stabil ID kullanıyoruz)

            // Eğer `playing` (aktif oyuncu sayısı) değeri mevcut değilse
            if (gameData.playing === undefined) {
                return interaction.reply({
                    content: 'Oyunun aktif oyuncu bilgisi şu anda alınamıyor. Lütfen daha sonra tekrar deneyin.',
                    ephemeral: true,
                });
            }

            // Embed ile sadece aktiflik bilgisi
            const embed = new EmbedBuilder()
                .setColor('Green')
                .setDescription(`🟢 Oyunun mevcut aktifliği: **${gameData.playing}** kişi`);

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            return interaction.reply({ content: 'Bir hata oluştu. Lütfen daha sonra tekrar deneyin.', ephemeral: true });
        }
    },
};
