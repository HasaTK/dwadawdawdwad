const { getFilteredRoles } = require('./Utils/autocomplete'); // autocomplete.js dosyasını içe aktar
const config = require('./config'); // config.js dosyasını içe aktar

(async () => {
    try {
        // Test için bir arama değeri belirleyin
        const searchQuery = '[OF'; // Örneğin, "[OF" ile başlayan rütbeleri arayın
        console.log(`Arama sorgusu: "${searchQuery}"`);

        // getFilteredRoles fonksiyonunu çağır
        const results = await getFilteredRoles(searchQuery);

        // Sonuçları yazdır
        console.log('Bulunan roller:', results);
    } catch (error) {
        console.error('Hata oluştu:', error);
    }
})();
