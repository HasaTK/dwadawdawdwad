const { SlashCommandBuilder } = require('discord.js');
const rowifiRequest = require('../../Utils/rowifiRequest');
const noblox = require('noblox.js');
const config = require('../../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('eğitim-duyuru')
        .setDescription('Seçilen rütbeye özel eğitim duyurusu gönderir.')
        .addStringOption(option =>
            option.setName('rütbe')
                .setDescription('Hedeflenen rütbeyi seçin')
                .setRequired(true)
                .addChoices(
                    { name: 'OR-1', value: 'OR-1+' },
                    { name: 'OR-2', value: 'OR-2+' },
                    { name: 'OR-3+', value: 'OR-3+' },
                )
        ),

    async execute(interaction) {
        const rank = interaction.options.getString('rütbe');
        const groupId = config.groupMain; // Grup ID'si
        const discordUserId = interaction.user.id; // Komutu kullanan Discord kullanıcısının ID'si
        const requiredRankId = 12; // Minimum rütbe ID'si
        const announcementChannelId = '1329880272698871869'; // Duyuru kanalının ID'si

        const roles = {
            'OR-1+': ['1233769845615755336'],
            'OR-2+': ['1233769843556225054'],
            'OR-3+': ['1233769842142744587', '1233769840301572117', '1233769839336882236', '1233769834043543583', '1233769833271922798', '1233769831749259294'],
        };

        const messages = {
            'OR-1+': `📢 **Eğitim Duyurusu**\n\nOyunda OR-1 Eğitimi Var. OR-1 Personeller oyuna bekleniyor.\n\n**Oyun Linki:**\nhttps://www.roblox.com/tr/games/86644961278890/T-rk-Asker-Oyunu\n\n`,
            'OR-2+': `📢 **Eğitim Duyurusu**\n\nOyunda OR-2 Eğitimi Var. OR-2 Personeller oyuna bekleniyor.\n\n**Oyun Linki:**\nhttps://www.roblox.com/tr/games/86644961278890/T-rk-Asker-Oyunu\n\n`,
            'OR-3+': `📢 **Eğitim Duyurusu**\n\nOyunda OR-3+ Eğitimi Var. OR-3+ Personeller oyuna bekleniyor.\n\n**Oyun Linki:**\nhttps://www.roblox.com/tr/games/86644961278890/T-rk-Asker-Oyunu\n\n`,
        };

        await interaction.deferReply(); // Kullanıcıya işlem yapıldığını bildir

        try {
            // Rowifi API ile komutu kullanan kişinin Roblox hesabını doğrula
            const rowifiData = await rowifiRequest(`/guilds/${interaction.guild.id}/members/${discordUserId}`);
            if (!rowifiData || !rowifiData.roblox_id) {
                return interaction.editReply({
                    content: `🚨 Bu komutu kullanabilmek için önce Discord hesabınızı Rowifi üzerinden Roblox hesabınıza bağlamanız gerekiyor.`,
                    ephemeral: true,
                });
            }

            const robloxUserId = rowifiData.roblox_id;

            // Kullanıcının mevcut rütbesini kontrol et
            const userCurrentRankId = await noblox.getRankInGroup(groupId, robloxUserId);
            const userCurrentRankName = await noblox.getRankNameInGroup(groupId, robloxUserId);

            if (userCurrentRankId === 0) {
                return interaction.editReply({
                    content: '⚠️ Roblox hesabınız belirtilen gruba üye değil. Bu komutu kullanamazsınız.',
                    ephemeral: true,
                });
            }

            if (userCurrentRankId < requiredRankId) {
                return interaction.editReply({
                    content: `⚠️ Bu komutu kullanmak için grubunuzdaki rütbenizin  "**Subay+**" olması gerekiyor. Şu anki rütbeniz: "${userCurrentRankName}".`,
                    ephemeral: true,
                });
            }

            // Mesajın içeriğini oluştur
            const selectedRoles = roles[rank];
            const taggedRoles = selectedRoles.map(roleId => `<@&${roleId}>`).join(' ');
            const messageToSend = `${messages[rank]}${taggedRoles}`;

            // Mesajı duyuru kanalına gönder
            const announcementChannel = interaction.client.channels.cache.get(announcementChannelId);
            if (!announcementChannel) {
                return interaction.editReply({
                    content: '⚠️ Duyuru kanalı bulunamadı. Lütfen ayarları kontrol edin.',
                    ephemeral: true,
                });
            }
            await announcementChannel.send(messageToSend);

            // Başarı mesajı
            await interaction.editReply({
                content: '📢 Eğitim duyurusu başarıyla duyuru kanalına gönderildi.',
                ephemeral: true,
            });
        } catch (error) {
            console.error('Hata:', error.message);
            await interaction.editReply({
                content: '⛔ Bir hata oluştu. Lütfen logları kontrol edin.',
                ephemeral: true,
            });
        }
    },
};
