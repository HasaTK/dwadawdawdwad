const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getFilteredRoles } = require('../../Utils/autocomplete');
const rowifiRequest = require('../../Utils/rowifiRequest');
const noblox = require('noblox.js');
const config = require('../../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rütbe-değiştir')
        .setDescription('Belirtilen kullanıcının Roblox grubundaki rütbesini değiştirir.')
        .addStringOption(option =>
            option.setName('kullanıcı')
                .setDescription('Rütbesi değiştirilecek kullanıcının Roblox kullanıcı adı')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('rütbe')
                .setDescription('Yeni rütbe (Seçerken öneriler çıkacak)')
                .setRequired(true)
                .setAutocomplete(true)
        )
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Rütbe değişikliğinin sebebi')
                .setRequired(true)
        ),

    async autocomplete(interaction) {
        try {
            const focusedValue = interaction.options.getFocused();
            const roles = await getFilteredRoles(focusedValue);

            if (!roles.length) {
                if (!interaction.responded) {
                    return await interaction.respond([{ name: 'Sonuç bulunamadı', value: '0' }]);
                }
            }

            if (!interaction.responded) {
                await interaction.respond(roles);
            }
        } catch (error) {
            console.error('Autocomplete sırasında hata oluştu:', error);
            if (!interaction.responded) {
                await interaction.respond([{ name: 'Hata oluştu', value: '0' }]);
            }
        }
    },

    async execute(interaction) {
        try {
            await interaction.deferReply({ ephemeral: true });

            const username = interaction.options.getString('kullanıcı');
            const rank = parseInt(interaction.options.getString('rütbe'));
            const reason = interaction.options.getString('sebep');
            const discordUserId = interaction.user.id;
            const logChannelId = config.logChannelId;

            const userId = await noblox.getIdFromUsername(username);
            const groupId = config.groupMain;

            // Mevcut rütbenin adını al
            const currentRankName = await noblox.getRankNameInGroup(groupId, userId);

            // Yeni rütbenin adını al
            const roles = await noblox.getRoles(groupId);
            const newRank = roles.find(role => role.rank === rank)?.name || "Bilinmiyor";

            if (currentRankName === newRank) {
                return interaction.editReply({
                    content: `🚨 Kullanıcı zaten bu rütbede.`,
                });
            }

            const rowifiData = await rowifiRequest(`/guilds/${interaction.guild.id}/members/${discordUserId}`);
            if (!rowifiData || !rowifiData.roblox_id) {
                return interaction.editReply({
                    content: `🚨 Bu komutu kullanabilmek için önce Discord hesabınızı Rowifi üzerinden Roblox hesabınıza bağlamanız gerekiyor.`,
                });
            }

            await noblox.setRank(groupId, userId, rank);

            const embed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setTitle('✅ Rütbe Değişikliği Başarılı!')
                .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
                .addFields(
                    { name: '📋 Roblox Kullanıcı Adı', value: username, inline: true },
                    { name: '📌 Eski Rütbe', value: currentRankName, inline: true },
                    { name: '🆕 Yeni Rütbe', value: newRank, inline: true },
                    { name: '📄 Sebep', value: reason, inline: false },
                )
                .setFooter({ text: `${interaction.guild.name} • ${new Date().toLocaleString()}` })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

            const logEmbed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setTitle('📝 Rütbe Değişikliği Log')
                .addFields(
                    { name: '📋 Roblox Kullanıcı Adı', value: username, inline: true },
                    { name: '📌 Eski Rütbe', value: currentRankName, inline: true },
                    { name: '🆕 Yeni Rütbe', value: newRank, inline: true },
                    { name: '⚙️ İşlem Yapan', value: interaction.user.tag, inline: true },
                    { name: '📄 Sebep', value: reason, inline: false },
                )
                .setFooter({ text: `${interaction.guild.name} • ${new Date().toLocaleString()}` })
                .setTimestamp();

            const logChannel = interaction.client.channels.cache.get(logChannelId);
            if (logChannel) {
                await logChannel.send({ embeds: [logEmbed] });
            }

        } catch (error) {
            console.error('Rütbe değiştirme sırasında hata:', error);
            await interaction.editReply({
                content: '⛔ Bir hata oluştu. Lütfen logları kontrol edin.',
            });
        }
    },
};
