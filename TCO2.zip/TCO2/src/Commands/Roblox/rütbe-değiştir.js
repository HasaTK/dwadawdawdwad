const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const noblox = require('noblox.js');
const rowifiRequest = require('../../Utils/rowifiRequest'); // Rowifi API yardımcı dosyası
const config = require('../../config'); // Config dosyasından cookie ve grup bilgisi alınır.

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rütbe-değiştir')
        .setDescription('Belirtilen kullanıcının Roblox grubundaki rütbesini değiştirir.')
        .addStringOption(option =>
            option.setName('kullanıcı')
                .setDescription('Rütbesi değiştirilecek kullanıcının Roblox kullanıcı adı')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('rütbe')
                .setDescription('Yeni rütbe (Seçeneklerden biri olmalı)')
                .setRequired(true)
                .addChoices(
                    { name: '[OR-1] Er', value: '1' },
                    { name: '[OR-2] Onbaşı', value: '2' },
                    { name: '[OR-3] Uzman Onbaşı', value: '3' },
                    { name: '[OR-4] Çavuş', value: '4' },
                    { name: '[OR-5] Uzman Çavuş', value: '5' },
                    { name: '[OR-6] Astsubay Çavuş', value: '7' },
                    { name: '[OR-7] Astsubay Kıdemli Başçavuş', value: '8' },
                    { name: '[OR-8] Astsubay Başçavuş', value: '9' },
                    { name: '[OR-9] Astsubay Kıdemli Başçavuş', value: '10' },
                    { name: '[OF-1/A] Asteğmen', value: '12' },
                    { name: '[OF-1/B] Teğmen', value: '13' },
                    { name: '[OF-1/C] Üsteğmen', value: '14' },
                    { name: '[OF-2] Yüzbaşı', value: '15' },
                    { name: '[OF-3] Binbaşı', value: '16' },
                    { name: '[OF-4] Yarbay', value: '17' },
                    { name: '[OF-5] Albay', value: '18' },
                    { name: '[OF-6] Tuğgeneral', value: '20' },
                    { name: '[OF-7] Tümgeneral', value: '21' },
                    { name: '[OF-8] Korgeneral', value: '22' },
                    { name: '[OF-9] Orgeneral', value: '23' },
                    { name: 'Büyük Konsey', value: '25' },
                    { name: 'Askeri Disiplin kurulu', value: '26' },
                    { name: 'Lider', value: '27' },
                    { name: 'Genel kurmay', value: '28' },
                    { name: 'Genel Kurmay Başkanı', value: '29' },
                )
        )
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Rütbe değişikliğinin sebebi')
                .setRequired(true)
        ),

    async execute(interaction) {
        const robloxUsername = interaction.options.getString('kullanıcı'); // Kullanıcı adı
        const rankInput = interaction.options.getString('rütbe'); // Yeni rütbe
        const reason = interaction.options.getString('sebep'); // Sebep
        const groupId = config.groupMain; // Grup ID
        const discordUserId = interaction.user.id; // Discord kullanıcı ID
        const requiredRankId = 20; // Minimum gerekli rütbe ID
        const logChannelId = config.logChannelId; // Log kanalı ID

        await interaction.deferReply(); // İşlemin sürdüğünü bildir

        try {
            const rowifiData = await rowifiRequest(`/guilds/${interaction.guild.id}/members/${discordUserId}`);
            if (!rowifiData || !rowifiData.roblox_id) {
                return interaction.editReply({
                    content: `🚨 Bu komutu kullanabilmek için önce Discord hesabınızı Rowifi üzerinden Roblox hesabınıza bağlamanız gerekiyor.`,
                    flags: 64,
                });
            }

            const robloxUserId = rowifiData.roblox_id;
            const userCurrentRankId = await noblox.getRankInGroup(groupId, robloxUserId);
            const userCurrentRankName = await noblox.getRankNameInGroup(groupId, robloxUserId);

            if (userCurrentRankId === 0) {
                return interaction.editReply({
                    content: '⚠️ Roblox hesabınız belirtilen gruba üye değil. Bu komutu kullanamazsınız.',
                    flags: 64,
                });
            }

            if (userCurrentRankId < requiredRankId) {
                return interaction.editReply({
                    content: `⚠️ Bu komutu kullanmak için grubunuzdaki rütbenizin en az "**[OF-6] Tuğgeneral**" olması gerekiyor. Şu anki rütbeniz: "${userCurrentRankName}".`,
                    flags: 64,
                });
            }

            const botUser = await noblox.setCookie(config.Cookie);
            if (!botUser) {
                throw new Error('Roblox botu giriş yapamadı. Lütfen config.Cookie değerini kontrol edin.');
            }

            const promoteRobloxUserId = await noblox.getIdFromUsername(robloxUsername).catch(() => null);
            if (!promoteRobloxUserId) {
                return interaction.editReply({
                    content: `⚠️ Kullanıcı adı "${robloxUsername}" geçerli değil veya kullanıcı bulunamadı.`,
                    flags: 64,
                });
            }

            const currentRankId = await noblox.getRankInGroup(groupId, promoteRobloxUserId);
            const currentRankName = await noblox.getRankNameInGroup(groupId, promoteRobloxUserId);

            if (currentRankId === parseInt(rankInput)) {
                return interaction.editReply({
                    content: `⚠️ Kullanıcının mevcut rütbesi zaten "${rankInput}" olarak ayarlanmış.`,
                    flags: 64,
                });
            }

            const promoteResponse = await noblox.setRank(groupId, promoteRobloxUserId, parseInt(rankInput));

            const updatedRankName = promoteResponse?.newRole?.name || await noblox.getRankNameInGroup(groupId, promoteRobloxUserId);

            const botAvatarURL = interaction.client.user.displayAvatarURL({ dynamic: true, size: 512 });

            // Sunucunun simgesini al
            const guildIconURL = interaction.guild.iconURL({ dynamic: true, size: 512 }) || 'https://i.imgur.com/zgARxNj.png';


            const embed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setAuthor({ name: '✅ Rütbe Değişikliği Başarılı!', iconURL: interaction.guild.iconURL({ dynamic: true, size: 512 }) })
                .setThumbnail(botAvatarURL) // Botun profil resmi
                .addFields(
                    { name: '👤 Roblox Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },    
                    { name: '📌 Eski Rütbe', value: `\`${currentRankName}\``, inline: true },
                    { name: '📈 Yeni Rütbe', value: `\`${updatedRankName}\``, inline: true },
                    { name: '📋 Sebep', value: reason, inline: false },
                )
                .setTimestamp()
                .setFooter({ text: `${interaction.guild.name} `, iconURL: guildIconURL });

            await interaction.editReply({ embeds: [embed] });

            // Log kanalı için embed
            const logEmbed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setAuthor({ name: '🔍 Rütbe Değişikliği Log', iconURL: interaction.guild.iconURL({ dynamic: true, size: 512 }) })
                .addFields(
                    { name: '👤 Roblox Kullanıcı Adı', value: `\`${robloxUsername}\``, inline: true },
                    { name: '📌 Eski Rütbe', value: `\`${currentRankName}\``, inline: true },
                    { name: '📈 Yeni Rütbe', value: `\`${updatedRankName}\``, inline: true },
                    { name: '🛠️ İşlem Yapan', value: interaction.member.displayName, inline: false },
                    { name: '📋 Sebep', value: reason, inline: false }
                )
                .setTimestamp();

            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.error('Rütbe değiştirme işlemi sırasında bir hata oluştu:', error);

            await interaction.editReply({
                content: '⚠️ Bir hata oluştu. Lütfen daha sonra tekrar deneyin.',
                flags: 64,
            });
        }
    },
};
