const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getFilteredRoles } = require('../../Utils/autocomplete');
const noblox = require('noblox.js');
const config = require('../../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rütbe-değiştir')
        .setDescription('Belirtilen kullanıcının Roblox grubundaki rütbesini değiştirir.')
        .addStringOption(option =>
            option.setName('kullanıcı')
                .setDescription('Rütbesi değiştirilecek kullanıcının Roblox kullanıcı adı')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('rütbe')
                .setDescription('Yeni rütbe (Seçerken öneriler çıkacak)')
                .setRequired(true)
                .setAutocomplete(true)
        )
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Rütbe değişikliğinin sebebi')
                .setRequired(true)
        ),

    async autocomplete(interaction) {
        try {
            const focusedValue = interaction.options.getFocused();
            const roles = await getFilteredRoles(focusedValue);

            if (!roles.length) {
                return await interaction.respond([{ name: 'Sonuç bulunamadı', value: '0' }]);
            }

            await interaction.respond(roles);
        } catch (error) {
            console.debug('Autocomplete sırasında hata oluştu:', error);
            await interaction.respond([{ name: 'Hata oluştu', value: '0' }]);
        }
    },

    async execute(interaction) {
        try {
            const username = interaction.options.getString('kullanıcı');
            const rank = parseInt(interaction.options.getString('rütbe')); // Yeni rütbe
            const reason = interaction.options.getString('sebep');
            const logChannelId = config.logChannelId;

            const userId = await noblox.getIdFromUsername(username);
            const groupId = config.groupMain;
            const currentRankId = await noblox.getRankInGroup(groupId, userId); // Mevcut rütbe ID'si
            const currentRankName = await noblox.getRankNameInGroup(groupId, userId); // Mevcut rütbe adı

            // Mevcut rütbe ile yeni rütbe aynıysa işlem yapılmasın
            if (currentRankId === rank) {
                return await interaction.reply({
                    content: `⚠️ Kullanıcı zaten bu rütbede: **${currentRankName}**`,
                    ephemeral: true,
                });
            }

            await noblox.setRank(groupId, userId, rank);

            const embed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setTitle('✅ Rütbe Değişikliği Başarılı!')
                .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
                .addFields(
                    { name: '📋 Roblox Kullanıcı Adı', value: username, inline: true },
                    { name: '📌 Eski Rütbe', value: `[${currentRankName}]`, inline: true },
                    { name: '🆕 Yeni Rütbe', value: rank.toString(), inline: true },
                    { name: '📄 Sebep', value: reason, inline: false },
                )
                .setFooter({ text: `${interaction.guild.name} • ${new Date().toLocaleString()}` })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

            const logEmbed = new EmbedBuilder()
                .setColor('#33ef5a')
                .setTitle('📝 Rütbe Değişikliği Log')
                .addFields(
                    { name: '📋 Roblox Kullanıcı Adı', value: username, inline: true },
                    { name: '📌 Eski Rütbe', value: `[${currentRankName}]`, inline: true },
                    { name: '🆕 Yeni Rütbe', value: rank.toString(), inline: true },
                    { name: '⚙️ İşlem Yapan', value: interaction.user.tag, inline: true },
                    { name: '📄 Sebep', value: reason, inline: false },
                )
                .setFooter({ text: `${interaction.guild.name} • ${new Date().toLocaleString()}` })
                .setTimestamp();

            const logChannel = interaction.client.channels.cache.get(logChannelId);
            if (logChannel) {
                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.debug('Rütbe değiştirme sırasında hata:', error);
            await interaction.reply({
                content: '⛔ Bir hata oluştu. Lütfen logları kontrol edin.',
                ephemeral: true,
            });
        }
    },
};
