const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("sustur-kaldir")
        .setDescription("Belirtilen üyenin susturmasını kaldırır.")
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Susturması kaldırılacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("sebep")
                .setDescription("Susturmayı kaldırma sebebini yazın.")
                .setRequired(true)
        ),

    async execute(interaction) {
        const { guild, options, member } = interaction;

        await interaction.deferReply({ ephemeral: false }); // Yanıt herkese açık

        const user = options.getUser('kullanıcı'); // İşlem yapılacak kullanıcı
        const reason = options.getString('sebep') || "Sebep belirtilmedi."; // Susturmayı kaldırma sebebi
        const timeMember = guild.members.cache.get(user.id); // Susturması kaldırılacak kullanıcı

        // İzin verilen rollerin ID'leri
        const allowedRoleIds = ['1233769721896374282', '1234583107676405780', '1233879749043159202', '1233769764376023120']; 
        const hasAllowedRole = allowedRoleIds.some(roleId => member.roles.cache.has(roleId));

        // Yetki kontrolü
        if (!hasAllowedRole) {
            return await interaction.editReply({ content: "Bu komutu kullanma yetkiniz yok!", ephemeral: true });
        }

        if (!timeMember) {
            return await interaction.editReply({ content: "Bu kullanıcı artık bu sunucuda değil!", ephemeral: true });
        }

        if (!timeMember.communicationDisabledUntilTimestamp) {
            return await interaction.editReply({ content: `<@${user.id}> adlı kullanıcı zaten susturulmamış!`, ephemeral: true });
        }

        // Susturmayı kaldırma işlemi
        try {
            await timeMember.timeout(null, reason); // Susturmayı kaldırmak için `null` kullanılır
        } catch (error) {
            console.error(error);
            return await interaction.editReply({ content: "Susturma kaldırılırken bir hata oluştu.", ephemeral: true });
        }

        // Kullanıcıya DM gönderme
        const dmEmbed = new EmbedBuilder()
            .setColor("#00FF00")
            .setTitle(`🔓 ${guild.name} Sunucusundaki Susturmanız Kaldırıldı!`)
            .setDescription(
                `**Sebep:** ${reason}\n` +
                `**Susturmayı Kaldıran:** ${interaction.user.tag}`
            )
            .setTimestamp();

        await user.send({ embeds: [dmEmbed] }).catch(() => {
            console.log(`Kullanıcı (${user.tag}) DM alamıyor.`);
        });

        // Herkese açık başarı mesajı
        const embed = new EmbedBuilder()
            .setColor("#00FF00")
            .setTitle("✅ Susturma Kaldırıldı!")
            .setDescription(
                `**Kullanıcı:** <@${user.id}> (${user.tag})\n` +
                `**Sebep:** ${reason}\n` +
                `**İşlemi Yapan:** ${interaction.user.tag}`
            )
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: "Susturma kaldırma işlemi tamamlandı", iconURL: guild.iconURL({ dynamic: true }) })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        // Log kanalı
        const logChannelId = '1328411376951234682'; // Log kanalınızın ID'si
        const logChannel = guild.channels.cache.get(logChannelId);

        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setColor("#FFFF00")
                .setTitle("🔓 Susturma Kaldırıldı (Log)")
                .setDescription(
                    `**Kullanıcı:** ${timeMember.user.tag} (${timeMember.user.id})\n` +
                    `**Susturmayı Kaldıran:** ${interaction.user.tag} (${interaction.user.id})\n` +
                    `**Sebep:** ${reason}`
                )
                .setThumbnail(timeMember.user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await logChannel.send({ embeds: [logEmbed] });
        }
    },
};
