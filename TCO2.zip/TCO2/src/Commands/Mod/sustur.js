const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("sustur")
        .setDescription("Belirtilen üyeyi susturur.")
        .addUserOption(option =>
            option
                .setName("kullanıcı")
                .setDescription("Susturulacak üyeyi seçin.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("süre")
                .setDescription("Susturma süresini belirtin (saniye, dakika, saat, gün).")
                .setRequired(true)
                .addChoices(
                    { name: "60 Saniye", value: "60" },
                    { name: "2 Dakika", value: "120" },
                    { name: "5 Dakika", value: "300" },
                    { name: "10 Dakika", value: "600" },
                    { name: "15 Dakika", value: "900" },
                    { name: "20 Dakika", value: "1200" },
                    { name: "30 Dakika", value: "1800" },
                    { name: "45 Dakika", value: "2700" },
                    { name: "1 Saat", value: "3600" },
                    { name: "2 Saat", value: "7200" },
                    { name: "3 Saat", value: "10800" },
                    { name: "5 Saat", value: "18000" },
                    { name: "10 Saat", value: "36000" },
                    { name: "1 Gün", value: "86400" },
                    { name: "2 Gün", value: "172800" },
                    { name: "3 Gün", value: "259200" },
                    { name: "1 Hafta", value: "604800" },
                )
        )
        .addStringOption(option =>
            option
                .setName("sebep")
                .setDescription("Susturma sebebi.")
                .setRequired(true)
        ),

    async execute(interaction) {
        const { guild, options, member } = interaction;

        const user = options.getUser('kullanıcı'); // Susturulacak kullanıcı
        const duration = parseInt(options.getString('süre')); // Susturma süresi
        const reason = options.getString('sebep') || "Sebep belirtilmedi."; // Susturma sebebi
        const timeMember = guild.members.cache.get(user.id); // Susturulacak üyenin bilgisi

        const allowedRoleIds = ['1233769721896374282', '1234583107676405780', '1233879749043159202', '1233769764376023120']; // İzin verilen rol ID'leri
        const hasAllowedRole = allowedRoleIds.some(roleId => member.roles.cache.has(roleId));
        if (!hasAllowedRole) {
            return await interaction.reply({ content: "Bu komutu kullanma yetkiniz yok!", ephemeral: true });
        }

        if (!timeMember) {
            return await interaction.reply({ content: "Bu kullanıcı artık bu sunucuda değil!", ephemeral: true });
        }
        if (!timeMember.kickable) {
            return await interaction.reply({ content: "Bu üyeye zaman aşımı uygulayamazsınız.", ephemeral: true });
        }
        if (interaction.member.id === timeMember.id) {
            return await interaction.reply({ content: "Kendinizi susturamazsınız!", ephemeral: true });
        }
        if (timeMember.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return await interaction.reply({ content: "Adminlere zaman aşımı uygulanamaz.", ephemeral: true });
        }

        try {
            await timeMember.timeout(duration * 1000, reason); // Zaman aşımını uygula
        } catch (error) {
            console.error(error);
            return await interaction.reply({ content: "Susturma işlemi sırasında bir hata oluştu.", ephemeral: true });
        }

        // Kullanıcıya DM gönder
        const dmEmbed = new EmbedBuilder()
            .setColor("#FF4500")
            .setTitle(`⚠️ ${guild.name} Sunucusunda Susturuldunuz!`)
            .setDescription(`**Sebep:** ${reason}\n**Süre:** ${duration / 60} dakika\n` +
                `Eğer bu bir hata olduğunu düşünüyorsanız sunucu yetkilileriyle iletişime geçin.`)
            .setTimestamp();

        await user.send({ embeds: [dmEmbed] }).catch(() => {
            console.log(`Kullanıcı (${user.tag}) DM alamıyor.`);
        });

        // Herkese görünür mesaj
        const embed = new EmbedBuilder()
            .setColor("Green")
            .setTitle("✅ Kullanıcı Susturuldu!")
            .setDescription(
                `<@${user.id}> adlı kullanıcı susturuldu.\n` +
                `**Süre:** ${duration / 60} dakika\n` +
                `**Sebep:** ${reason}\n` +
                `**Susturan:** ${interaction.user.tag}`
            )
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });

        // Log kanalı
        const logChannelId = '1328411376951234682'; // Log kanal ID'si
        const logChannel = guild.channels.cache.get(logChannelId);
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setColor("Yellow")
                .setTitle("🔒 Kullanıcı Susturuldu (Log)")
                .setDescription(
                    `**Kullanıcı:** <@${timeMember.user.id}> (${timeMember.user.tag})\n` +
                    `**Susturan:** ${interaction.user.tag} (${interaction.user.id})\n` +
                    `**Süre:** ${duration / 60} dakika\n` +
                    `**Sebep:** ${reason}`
                )
                .setTimestamp();

            await logChannel.send({ embeds: [logEmbed] });
        }
    },
};
