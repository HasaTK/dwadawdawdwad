const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("unban")
        .setDescription("Belirtilen üyenin banını kaldır.")
        .setDefaultMemberPermissions(PermissionsBitField.Flags.BanMembers) // Ban members yetkisi olanlar kullanabilir
        .addStringOption(option =>
            option
                .setName("userid")
                .setDescription("Banını kaldırmak istediğiniz üyenin ID'sini girin.")
                .setRequired(true)
        ),

    async execute(interaction) {
        const userId = interaction.options.getString("userid");

        // Yetki kontrolü: Kullanıcı ban kaldırma yetkisine sahip mi?
        const member = interaction.member;
        if (!member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
            const noPermissionEmbed = new EmbedBuilder()
                .setColor("Red")
                .setTitle("Yetki Hatası")
                .setDescription("Bu komutu kullanma izniniz yok. 'Ban Members' yetkisine sahip olmalısınız.")
                .setTimestamp();

            return interaction.reply({
                embeds: [noPermissionEmbed],
                ephemeral: true, // Yanıt yalnızca komutu giren kişiye gösterilir
            });
        }

        try {
            const guild = interaction.guild;

            // Üyeyi unban yap
            await guild.members.unban(userId);

            // Başarılı işlem mesajı
            const embed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("İşlem başarıyla tamamlandı!")
                .setDescription(`<@${userId}> kullanıcısının banı kaldırıldı.`) // Kullanıcıyı etiketler
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);

            // Hata mesajı
            const errorEmbed = new EmbedBuilder()
                .setColor("Red")
                .setTitle("Bir hata oluştu!")
                .setDescription(
                    `Geçerli bir kullanıcı ID'si giriniz veya bu kullanıcı banlı olmayabilir.`
                )
                .setTimestamp();

            await interaction.reply({
                embeds: [errorEmbed],
                ephemeral: true, // Kullanıcıya özel mesaj gönderilir
            });
        }
    },
};
