const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('aktif') // Komut adı
        .setDescription('Duyuru kanalına aktiflik mesajı gönderir.') // Komut açıklaması
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator), // Sadece adminlere izin ver
    async execute(interaction) {
        const announcementChannelId = '1327788505694208105'; // Duyuru kanalının kimliği (ID)
        const gameLink = 'https://www.roblox.com/tr/games/86644961278890/TCO-T-rk-Asker-Oyunu'; // Oyun linki

        // Kanalı al
        const channel = interaction.client.channels.cache.get(announcementChannelId);
        if (!channel) {
            return interaction.reply({
                content: 'Duyuru kanalı bulunamadı. Lütfen kanal kimliğini kontrol edin.',
                ephemeral: true,
            });
        }

        try {
            // Metin mesajını gönder (tag ile birlikte)
            await channel.send({
                content: `**Aktiflik Duyuru**\nAktif olan herkes oyuna bekleniyor!\nOyun Linki: ${gameLink} \n<@&1233769847196880981>`,
            });
            

            // Komut kullanan kullanıcıya başarı mesajı gönder
            await interaction.reply({
                content: 'Duyuru başarıyla gönderildi!',
                ephemeral: true,
            });
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: 'Duyuru gönderilirken bir hata oluştu.',
                ephemeral: true,
            });
        }
    },
};
