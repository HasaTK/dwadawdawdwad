const { SlashCommandBuilder } = require('discord.js');
const rowifiRequest = require('../../Utils/rowifiRequest'); // Rowifi doğrulaması için kullanılıyor

module.exports = {
    data: new SlashCommandBuilder()
        .setName('eğitim-duyuru')
        .setDescription('Seçilen rütbeye özel eğitim duyurusu gönderir.')
        .addStringOption(option =>
            option.setName('rütbe')
                .setDescription('Hedeflenen rütbeyi seçin')
                .setRequired(true)
                .addChoices(
                    { name: 'OR-1', value: 'OR-1+' },
                    { name: 'OR-2', value: 'OR-2+' },
                    { name: 'OR-3+', value: 'OR-3+' },
                )
        ),

    async execute(interaction) {
        const rank = interaction.options.getString('rütbe');
        const requiredRank = 12; // Minimum rütbe ID'si
        const groupId = 13693196; // Kontrol edilecek Roblox grubu ID'si
        const announcementChannelId = '1233769992336441465'; // Duyuru kanalının ID'si

        // Roller ve mesaj formatı
        const roles = {
            'OR-1+': ['1233769845615755336'], // OR-1'e ait rol ID'leri
            'OR-2+': ['1233769843556225054'], // OR-2'ye ait rol ID'leri
            'OR-3+': ['1233769842142744587', '1233769840301572117', '1233769839336882236', '1233769834043543583', '1233769833271922798', '1233769831749259294'], // OR-3'e ait rol ID'leri
        };

        const messages = {
            'OR-1+': `📢 **Eğitim Duyurusu**\n\nOyunda OR-1 Eğitimi Var. OR-1 Personeller oyuna bekleniyor.\n\n**Oyun Linki:**\nhttps://www.roblox.com/tr/games/86644961278890/T-rk-Asker-Oyunu\n\n`,
            'OR-2+': `📢 **Eğitim Duyurusu**\n\nOyunda OR-2 Eğitimi Var. OR-2 Personeller oyuna bekleniyor.\n\n**Oyun Linki:**\nhttps://www.roblox.com/tr/games/86644961278890/T-rk-Asker-Oyunu\n\n`,
            'OR-3+': `📢 **Eğitim Duyurusu**\n\nOyunda OR-3+ Eğitimi Var. OR-3+ Personeller oyuna bekleniyor.\n\n**Oyun Linki:**\nhttps://www.roblox.com/tr/games/86644961278890/T-rk-Asker-Oyunu\n\n`,
        };

        try {
            // Kullanıcı bilgilerini Rowifi API'den al
            const discordId = interaction.user.id;
            const userInfo = await rowifiRequest(`/user/${discordId}`);
            const robloxId = userInfo.robloxId;

            // Kullanıcının gruptaki rütbesini kontrol et
            const groupInfo = await rowifiRequest(`/groups/${groupId}/users/${robloxId}`);
            if (groupInfo.rank < requiredRank) {
                return interaction.reply({
                    content: '⛔ Bu komutu kullanabilmek için grupta en az Subay veya üzeri olmanız gerekmektedir.',
                    ephemeral: true,
                });
            }

            const selectedRoles = roles[rank];
            const taggedRoles = selectedRoles.map(roleId => `<@&${roleId}>`).join(' ');

            // Mesajın içeriğini oluştur
            const messageToSend = `${messages[rank]}${taggedRoles}`;

            // Mesajı duyuru kanalına gönder
            const announcementChannel = interaction.client.channels.cache.get(announcementChannelId);
            if (!announcementChannel) {
                return interaction.reply({
                    content: '⚠️ Duyuru kanalı bulunamadı. Lütfen ayarları kontrol edin.',
                    ephemeral: true,
                });
            }
            await announcementChannel.send(messageToSend);

            // Kullanıcıya özel mesajla işlem tamamlandığını bildir
            await interaction.reply({
                content: '📢 Eğitim duyurusu başarıyla duyuru kanalına gönderildi.',
                ephemeral: false,
            });
        } catch (error) {
            console.error('Rowifi doğrulama veya mesaj gönderim hatası:', error);
            await interaction.reply({
                content: '⛔ Bir hata oluştu. Lütfen logları kontrol edin.',
                ephemeral: true,
            });
        }
    },
};
