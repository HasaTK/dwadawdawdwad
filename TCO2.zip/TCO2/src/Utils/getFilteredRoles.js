const noblox = require('noblox.js');
const config = require('../config');

const rolesCache = new Map();

async function getFilteredRoles(input = '') {
    try {
        // Eğer önbellekte varsa direkt döndür
        if (rolesCache.has(input)) {
            return rolesCache.get(input);
        }

        // Roblox API'den grup rütbelerini çek
        const roles = await noblox.getRoles(config.groupMain);

        // Filtrele ve Discord formatına dönüştür
        const filteredRoles = roles
            .filter(role => role.name.toLowerCase().includes(input.toLowerCase())) // Filtreleme
            .slice(0, 25) // Discord autocomplete sınırına uygun hale getir
            .map(role => ({ name: role.name, value: role.rank.toString() }));

        // Önbelleğe kaydet
        rolesCache.set(input, filteredRoles);

        return filteredRoles;
    } catch (error) {
        console.error('Rütbeler alınırken hata:', error);
        return [];
    }
}

module.exports = {
    getFilteredRoles,
};

// TEST KODU
(async () => {
    const roles = await getFilteredRoles('general'); // Örnek input
    console.log('Filtrelenmiş Rütbeler:', roles);
})();
