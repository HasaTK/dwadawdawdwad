const axios = require('axios');

/**
 * Belirtilen Universe ID'ye ait bilgileri alır.
 * @param {number} universeId - Roblox Universe ID
 * @returns {Promise<Object>} Universe bilgileri
 */
async function getUniverseDetails(universeId) {
    try {
        const response = await axios.get(
            `https://games.roblox.com/v1/games?universeIds=${universeId}`
        );
        const universeDetails = response.data.data[0]; // İlk elemanı al
        console.log('Alınan Universe Detayları:', universeDetails); // Konsola yazdır
        return universeDetails;
    } catch (error) {
        console.error(`Universe bilgileri alınırken hata oluştu: ${error.message}`);
        return null;
    }
}

module.exports = {
    getUniverseDetails,
};
