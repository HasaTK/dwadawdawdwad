const noblox = require('noblox.js');
const config = require('../config');

// Grubun rollerini alır
async function getGroupRoles() {
    try {
        const roles = await noblox.getRoles(config.groupMain);
        return roles.slice(0, 25); // İlk 25 rütbeyi döndür
    } catch (error) {
        console.error('Rütbeler alınırken bir hata oluştu:', error);
        return [];
    }
}

// Kullanıcının mevcut rütbesini alır
async function getUserRole(groupId, robloxUserId) {
    try {
        const rankId = await noblox.getRankInGroup(groupId, robloxUserId);
        if (rankId === 0) return null; // Kullanıcı grupta değilse null döner

        const roles = await noblox.getRoles(groupId);
        const role = roles.find(r => r.rank === rankId);
        return role || null;
    } catch (error) {
        console.error('Kullanıcının rütbesi alınırken bir hata oluştu:', error);
        return null;
    }
}

// Grubun belirli bir rütbesini alır
async function getRoleById(groupId, rankId) {
    try {
        const roles = await noblox.getRoles(groupId);
        return roles.find(r => r.rank === rankId) || null;
    } catch (error) {
        console.error('Rol alınırken bir hata oluştu:', error);
        return null;
    }
}

module.exports = {
    getGroupRoles,
    getUserRole,
    getRoleById,
};
