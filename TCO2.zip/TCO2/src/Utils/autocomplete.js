const noblox = require('noblox.js');
const config = require('../config');

async function getFilteredRoles(input) {
    try {
        const groupRoles = await noblox.getRoles(config.groupMain); // Roblox grup rollerini çek

        if (!input) {
            // Kullanıcı bir şey yazmadıysa, ilk 25 rütbeyi döndür
            return groupRoles
                .slice(0, 25) // İlk 25 rütbeyi al
                .map(role => ({ name: role.name, value: role.rank.toString() }));
        }

        // Kullanıcı bir şey yazdıysa, buna göre filtrele
        const filteredRoles = groupRoles
            .filter(role => role.name.toLowerCase().includes(input.toLowerCase())) // Filtrele
            .slice(0, 25) // Discord'un autocomplete sınırına dikkat et
            .map(role => ({ name: role.name, value: role.rank.toString() }));

        return filteredRoles;
    } catch (error) {
        console.error('Rütbeler alınırken hata:', error);
        return [];
    }
}

module.exports = {
    getFilteredRoles,
};

// TEST KODU: getFilteredRoles fonksiyonunu test etmek için
(async () => {
    const { getFilteredRoles } = require('./autocomplete'); // Autocomplete fonksiyonu
    const roles = await getFilteredRoles(''); // Boş input ile test
    console.log('Alınan Rütbeler:', roles);
})();
