const fetch = require('node-fetch');
const config = require('../config');

async function rowifiRequest(endpoint, method = 'GET', body = null) {
    const url = `https://api.rowifi.xyz/v3${endpoint}`;
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bot ${config.API_KEY}`, // API token
    };

    const options = { method, headers };
    if (body) options.body = JSON.stringify(body);

    // Timeout için AbortController oluştur
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000); // 10 saniye timeout
    options.signal = controller.signal;

    try {
        const response = await fetch(url, options);
        clearTimeout(timeout); // Timeout temizlenir

        // Yanıtın JSON olup olmadığını kontrol et
        let data;
        try {
            data = await response.json();
        } catch (jsonError) {
            throw new Error('Geçersiz JSON yanıtı alındı.');
        }

        // API Hatası varsa kontrol et
        if (!response.ok) {
            throw new Error(data.message || 'Rowifi API isteği başarısız oldu.');
        }

        return data; // Başarılı yanıt
    } catch (error) {
        if (error.name === 'AbortError') {
            console.error('Rowifi API Hatası: İstek zaman aşımına uğradı.');
            throw new Error('İstek zaman aşımına uğradı. Lütfen tekrar deneyin.');
        }

        console.error('Rowifi API Hatası:', error.message);
        throw error; // Diğer hataları tekrar fırlat
    } finally {
        clearTimeout(timeout); // Timeout her durumda temizlenir
    }
}

module.exports = rowifiRequest;
