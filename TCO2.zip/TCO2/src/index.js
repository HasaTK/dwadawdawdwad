const {
    ActivityType,
    Client,
    Collection,
    GatewayIntentBits,
    Partials,
    ApplicationCommandType,
    EmbedBuilder,
    Message,
} = require('discord.js');
const noblox = require('noblox.js');
const fs = require('fs');
const path = require('path');
const configFile = require('./config.js');
const consola = require('consola');
const AntiCrash = require('./Utils/Functions/AntiCrash.js');
const { embed } = require('./Utils/Functions/embed.js');


const client = new Client({
    intents: Object.values(GatewayIntentBits),
    partials: Object.values(Partials),
    allowedMentions: {
        parse: ['users', 'roles'],
        repliedUser: true,
    },
    presence: {
        status: 'dnd',
        activities: [
            {
                name: 'Realnqa Tarafından Yapılmıstır',
                type: ActivityType.Playing,
            },
        ],
    },
});

async function connectToRoblox() {
    try {
        // Roblox çerezinizi buraya yapıştırın
        const cookie = configFile.Cookie; // Çerez değeriniz buraya
        await noblox.setCookie(cookie);

        // Başarılı bağlantı mesajı
        const currentUser = await noblox.getAuthenticatedUser();
        console.log(`Başarıyla bağlanıldı! Giriş yapılan hesap: ${currentUser.name}`);
    } catch (error) {
        console.error('Hata oluştu:', error.message);
    }
}

connectToRoblox();

client.commands = new Collection();
client.context = new Collection();
client.config = configFile;
client.embed = embed;

require("./Utils/slashCommandsLoader.js")(client);
require("./Utils/eventsLoader.js")(client);

AntiCrash()
client.login(client.config.token);
