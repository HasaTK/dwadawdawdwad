const { EmbedBuilder } = require('discord.js');
const consola = require('consola');

module.exports = {
    name: "interactionCreate",
    run: async (client, interaction) => {
        if (interaction.isAutocomplete()) {
            const command = client.commands.get(interaction.commandName);
            if (!command || !command.autocomplete) return;

            try {
                await command.autocomplete(interaction);
            } catch (error) {
                consola.error('Autocomplete sırasında hata oluştu:', error);
                if (!interaction.responded) {
                    await interaction.respond([{ name: 'Hata oluştu', value: '0' }]);
                }
            }
        }

        if (!interaction.isChatInputCommand()) return;

        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        // Sunucu dışı komutları engelle
        if (!interaction.guild) {
            return interaction.reply({
                content: 'Bu komut sadece sunucularda kullanılabilir.',
                ephemeral: true,
            });
        }

        // Komut çalıştırma
        try {
            await command.execute(interaction);
        } catch (error) {
            consola.error('Komut çalıştırılırken hata oluştu:', error);

            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle('⚠️ Bir hata oluştu!')
                            .setDescription('Komut çalıştırılırken bir hata oluştu. Lütfen daha sonra tekrar deneyin.')
                            .setColor('33ef5a'),
                    ],
                    ephemeral: true,
                });
            } else {
                await interaction.followUp({
                    content: '⚠️ Bir hata oluştu. Lütfen logları kontrol edin.',
                    ephemeral: true,
                });
            }
        }
    },
};
