const { Collection, EmbedBuilder } = require('discord.js');
const config = require('../../config');
const consola = require('consola'); // Daha iyi loglama için consola kullanımı

module.exports = {
    name: "interactionCreate",
    run: async (client, interaction) => {
        try {
            // **Autocomplete İşlemleri**
            if (interaction.isAutocomplete()) {
                const command = client.commands.get(interaction.commandName);
                if (!command || !command.autocomplete) return;

                try {
                    await command.autocomplete(interaction);
                } catch (error) {
                    consola.error('Autocomplete sırasında hata oluştu:', error);
                }
                return; // İşlem burada tamamlanır
            }

            // **Sohbet Komutları İşlemleri**
            if (!interaction.isChatInputCommand()) return;

            const command = client.commands.get(interaction.commandName);
            if (!command) return; // Geçerli bir komut yoksa çık
            if (!interaction.guild) {
                // DM'den çalıştırılmaya çalışılan komutları engelle
                await interaction.reply({
                    content: "Bu komut yalnızca sunucularda çalıştırılabilir.",
                    ephemeral: true,
                });
                return;
            }

            // Komut Parametrelerinin İşlenmesi
            interaction.selectedValue = interaction.options._hoistedOptions[0]?.value;

            // Komutun `execute` Fonksiyonunu Çalıştır
            try {
                await command.execute(interaction);
            } catch (error) {
                consola.error(`Komut çalıştırılırken hata oluştu:`, error);
                await interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle("⚠️ Bir Hata Oluştu")
                            .setDescription("Komut çalıştırılırken bir hata oluştu. Lütfen daha sonra tekrar deneyin.")
                            .setColor("#FF0000")
                    ],
                    ephemeral: true,
                });
            }
        } catch (globalError) {
            // Genel bir hata durumunda
            consola.error('Genel bir hata oluştu:', globalError);
            if (interaction.replyable) {
                await interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle("⚠️ Bir Hata Oluştu")
                            .setDescription("Beklenmeyen bir hata meydana geldi. Lütfen daha sonra tekrar deneyin.")
                            .setColor("#FF0000")
                    ],
                    ephemeral: true,
                });
            }
        }
    }
};
