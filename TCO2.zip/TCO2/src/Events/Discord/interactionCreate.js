const { Collection, EmbedBuilder } = require('discord.js');
const config = require('../../config');
const consola = require('consola');

module.exports = {
    name: "interactionCreate",
    run: async (client, interaction) => {
        if (interaction.isAutocomplete()) {
            const command = client.commands.get(interaction.commandName);
            if (!command || !command.autocomplete) return;

            try {
                await command.autocomplete(interaction);
            } catch (error) {
                consola.error('Autocomplete hatası:', error);
            }
        }

        if (!interaction.isChatInputCommand()) return;

        const command = client.commands.get(interaction.commandName);
        if (!command) return;
        if (interaction.guild == null) return;

        interaction.selectedValue = interaction.options._hoistedOptions[0]?.value;

        try {
            await command.execute(interaction);
        } catch (error) {
            consola.error(error);
            await interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle("Bir hata oluştu!")
                        .setDescription("Komut çalıştırılırken bir hata oluştu!")
                ],
            });
        }
    }
}
